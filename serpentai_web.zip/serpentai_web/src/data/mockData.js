export const mockStats = [
    { label: 'Total Uploads', value: '1,248', change: '+12%', icon: '📁' },
    { label: 'Storage Used', value: '45.2 GB', change: '+5%', icon: '☁️' },

    { label: 'Threats Detected', value: '12', change: '-2%', icon: '🛡️' }
];

export const mockUploads = [
    { id: 1, name: 'dataset_v1.csv', size: '2.4 MB', type: 'CSV', date: '2023-10-24' },
    { id: 2, name: 'image_batch_001.zip', size: '156 MB', type: 'ZIP', date: '2023-10-23' },
    { id: 3, name: 'analysis_report.pdf', size: '4.1 MB', type: 'PDF', date: '2023-10-22' },
    { id: 4, name: 'model_weights.h5', size: '450 MB', type: 'H5', date: '2023-10-21' },
    { id: 5, name: 'logs_2023.txt', size: '12 KB', type: 'TXT', date: '2023-10-20' },
    { id: 6, name: 'presentation.pptx', size: '12 MB', type: 'PPTX', date: '2023-10-19' }
];

export const mockActivity = [
    { id: 1, user: 'You', action: 'uploaded', target: 'dataset_v1.csv', time: '2 mins ago' },
    { id: 2, user: 'System', action: 'detected threat', target: 'malware_sig.bin', time: '1 hour ago' },
    { id: 3, user: 'You', action: 'deleted', target: 'temp_files.zip', time: '3 hours ago' },
    { id: 4, user: 'Admin', action: 'updated settings', target: 'Security Policy', time: '1 day ago' },
    { id: 5, user: 'You', action: 'downloaded', target: 'report_final.pdf', time: '2 days ago' }
];
