// Replace these with your actual Supabase project details
export const SUPABASE_URL = 'https://tykvubhrbmizwlnbchfd.supabase.co';
export const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR5a3Z1YmhyYm1pendsbmJjaGZkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjA4ODg0NTAsImV4cCI6MjA3NjQ2NDQ1MH0.QwK0T8q4WCwynlyqczvvqSAaROkQquHxP6mX9miQoNg';
