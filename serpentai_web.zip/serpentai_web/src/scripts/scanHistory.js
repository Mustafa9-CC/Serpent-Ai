const STORAGE_KEY = 'serpent_ai_scan_history';

export const scanHistory = {
    getScans(userId) {
        if (!userId) return [];
        const key = `${STORAGE_KEY}_${userId}`;
        const scans = localStorage.getItem(key);
        return scans ? JSON.parse(scans) : [];
    },

    addScan(scan, userId) {
        if (!userId) return;
        const scans = this.getScans(userId);
        // Add new scan to the beginning
        scans.unshift({
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            ...scan
        });
        // Limit to last 50 scans
        if (scans.length > 50) {
            scans.length = 50;
        }
        const key = `${STORAGE_KEY}_${userId}`;
        localStorage.setItem(key, JSON.stringify(scans));
    },

    clearHistory(userId) {
        if (!userId) return;
        const key = `${STORAGE_KEY}_${userId}`;
        localStorage.removeItem(key);
    }
};
