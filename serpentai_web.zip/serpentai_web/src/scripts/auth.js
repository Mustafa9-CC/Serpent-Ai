import { SUPABASE_URL, SUPABASE_ANON_KEY } from '../config.js';

// Initialize Supabase client
// We assume the supabase-js library is loaded via CDN and available globally as `supabase`
let supabaseClient = null;

if (window.supabase) {
    supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
} else {
    console.error('Supabase library not loaded!');
}

export const auth = {
    client: supabaseClient,

    async signUp(email, password) {
        if (!supabaseClient) return { error: { message: 'Supabase not initialized' } };
        const { data, error } = await supabaseClient.auth.signUp({
            email,
            password,
        });
        return { data, error };
    },

    async signIn(email, password) {
        if (!supabaseClient) return { error: { message: 'Supabase not initialized' } };
        const { data, error } = await supabaseClient.auth.signInWithPassword({
            email,
            password,
        });
        return { data, error };
    },

    async signInWithGoogle() {
        if (!supabaseClient) return { error: { message: 'Supabase not initialized' } };
        const { data, error } = await supabaseClient.auth.signInWithOAuth({
            provider: 'google',
            options: {
                redirectTo: window.location.href.split('#')[0] // Redirect back to current page (preserving subdirectory)
            }
        });
        return { data, error };
    },

    async signOut() {
        if (!supabaseClient) return { error: { message: 'Supabase not initialized' } };
        const { error } = await supabaseClient.auth.signOut();
        return { error };
    },

    async getUser() {
        if (!supabaseClient) return null;
        const { data: { user } } = await supabaseClient.auth.getUser();
        return user;
    },

    onAuthStateChange(callback) {
        if (!supabaseClient) return;
        supabaseClient.auth.onAuthStateChange((event, session) => {
            callback(event, session);
        });
    },

    async updateProfile(updates) {
        if (!supabaseClient) return { error: { message: 'Supabase not initialized' } };
        const { data, error } = await supabaseClient.auth.updateUser({
            data: updates
        });
        return { data, error };
    }
};
