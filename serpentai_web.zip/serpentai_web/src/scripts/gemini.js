
const API_KEY = 'AIzaSyBGOlvOiuBExQsM2D6umcLSLdQfUspmRvY'; // Placeholder - User to replace

export const gemini = {
    async analyzeImage(file) {
        if (!API_KEY || API_KEY === 'YOUR_GEMINI_API_KEY') {
            console.warn('Gemini API Key is missing.');
            return {
                error: 'API Key missing. Please configure your Gemini API key in src/scripts/gemini.js'
            };
        }

        try {
            // 1. Convert file to Base64
            const base64Data = await this.fileToBase64(file);

            // 2. Prepare Request Body
            const requestBody = {
                contents: [{
                    parts: [
                        { text: "Identify this snake. Provide the following details in JSON format: { \"name\": \"Common Name\", \"scientific\": \"Scientific Name\", \"venom\": \"Venomous/Non-venomous\", \"danger\": \"High/Medium/Low\", \"confidence\": 95, \"description\": \"Brief description...\" }. If it's not a snake, return { \"error\": \"Not a snake\" }." },
                        {
                            inline_data: {
                                mime_type: file.type,
                                data: base64Data
                            }
                        }
                    ]
                }]
            };

            // 3. Call Gemini API (gemini-1.5-flash-latest)
            const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=${API_KEY}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(requestBody)
            });

            if (!response.ok) {
                const errorBody = await response.text();
                console.error('Gemini API Error Details:', errorBody);
                throw new Error(`API Error: ${response.status} - ${errorBody}`);
            }

            const data = await response.json();
            const text = data.candidates[0].content.parts[0].text;

            // 4. Parse JSON from response text (handling potential markdown code blocks)
            const jsonString = text.replace(/```json/g, '').replace(/```/g, '').trim();
            return JSON.parse(jsonString);

        } catch (error) {
            console.error('Gemini Analysis Error:', error);
            return {
                error: 'Failed to analyze image. Please try again.'
            };
        }
    },

    fileToBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => {
                // Remove data URL prefix (e.g., "data:image/jpeg;base64,")
                const base64String = reader.result.split(',')[1];
                resolve(base64String);
            };
            reader.onerror = error => reject(error);
        });
    }
};
