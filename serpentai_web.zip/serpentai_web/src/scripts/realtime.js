// Simulate realtime subscriptions
export const realtime = {
    subscribe(channel, callback) {
        console.log(`Subscribed to ${channel}`);

        // Simulate random events
        const interval = setInterval(() => {
            if (Math.random() > 0.7) {
                const actions = ['uploaded', 'deleted', 'modified', 'viewed'];
                const targets = ['file.txt', 'image.png', 'data.csv', 'report.pdf'];

                const event = {
                    user: 'System',
                    action: actions[Math.floor(Math.random() * actions.length)],
                    target: targets[Math.floor(Math.random() * targets.length)],
                    time: 'Just now'
                };

                callback(event);
            }
        }, 10000); // Every 10 seconds

        return {
            unsubscribe: () => {
                clearInterval(interval);
                console.log(`Unsubscribed from ${channel}`);
            }
        };
    }
};
