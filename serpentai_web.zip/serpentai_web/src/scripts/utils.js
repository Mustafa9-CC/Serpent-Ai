/**
 * Loads an HTML component from a file.
 * Injects <style> tags into the document head.
 * Returns the first element found in the body of the loaded HTML.
 * @param {string} url - Path to the HTML file
 * @returns {Promise<HTMLElement>}
 */
export async function loadComponent(url) {
    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error(`Failed to load component: ${url}`);
        const html = await response.text();

        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');

        // Move styles to head
        const styles = doc.querySelectorAll('style');
        styles.forEach(style => document.head.appendChild(style));

        // Return the root element
        // We assume the component HTML has a single root element in body
        return doc.body.firstElementChild;
    } catch (error) {
        console.error(error);
        const errorDiv = document.createElement('div');
        errorDiv.style.color = 'red';
        errorDiv.textContent = `Error loading component: ${url}`;
        return errorDiv;
    }
}
