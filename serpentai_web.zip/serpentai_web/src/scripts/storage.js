import { auth } from './auth.js';

const BUCKET_NAME = 'user_uploads';

export const storage = {
    async listFiles() {
        if (!auth.client) return [];

        const user = await auth.getUser();
        if (!user) return [];
        const userId = user.id;

        const { data, error } = await auth.client
            .storage
            .from(BUCKET_NAME)
            .list(userId + '/', {
                limit: 100,
                offset: 0,
                sortBy: { column: 'name', order: 'asc' },
            });

        if (error) {
            console.error('Error listing files:', error);
            return [];
        }

        return data.map(file => {
            const size = file.metadata ? (file.metadata.size / 1024 / 1024).toFixed(2) + ' MB' : '0 MB';
            const type = file.metadata && file.metadata.mimetype ? file.metadata.mimetype.split('/')[1].toUpperCase() : 'FILE';

            return {
                id: file.name, // This is just the filename relative to the folder
                name: file.name,
                size: size,
                type: type,
                date: new Date(file.created_at).toLocaleDateString(),
                created_at: file.created_at
            };
        });
    },

    async uploadFile(file) {
        if (!auth.client) return null;

        const user = await auth.getUser();
        if (!user) return null;
        const userId = user.id;

        // Create a unique file name to avoid collisions and sanitize it
        const sanitizedName = file.name.replace(/[^a-zA-Z0-9.-]/g, '_');
        const fileName = `${Date.now()}_${sanitizedName}`;
        const filePath = `${userId}/${fileName}`;

        const { data, error } = await auth.client
            .storage
            .from(BUCKET_NAME)
            .upload(filePath, file);

        if (error) {
            console.error('Error uploading file:', error);
            alert(`Upload failed: ${error.message}`);
            return null;
        }

        return {
            id: fileName,
            name: fileName,
            size: (file.size / 1024 / 1024).toFixed(2) + ' MB',
            type: file.type.split('/')[1].toUpperCase(),
            date: new Date().toLocaleDateString(),
            created_at: new Date().toISOString()
        };
    },

    async deleteFile(fileName) {
        if (!auth.client) return false;

        const user = await auth.getUser();
        if (!user) return false;
        const userId = user.id;

        const filePath = `${userId}/${fileName}`;

        const { error } = await auth.client
            .storage
            .from(BUCKET_NAME)
            .remove([filePath]);

        if (error) {
            console.error('Error deleting file:', error);
            return false;
        }

        return true;
    },

    getPublicUrl(fileName, userId = null) {
        if (!auth.client) return null;

        let path = fileName;
        if (userId) {
            path = `${userId}/${fileName}`;
        }

        const { data } = auth.client.storage.from(BUCKET_NAME).getPublicUrl(path);
        return data.publicUrl;
    },

    async getSignedUrl(fileName) {
        if (!auth.client) return null;

        const user = await auth.getUser();
        if (!user) return null;
        const userId = user.id;
        const path = `${userId}/${fileName}`;

        const { data, error } = await auth.client.storage.from(BUCKET_NAME).createSignedUrl(path, 3600); // 1 hour expiry
        if (error) {
            // If object not found, just return null (file might have been deleted)
            if (error.message && error.message.includes('Object not found')) {
                console.warn('File not found in storage:', path);
                return null;
            }
            console.error('Error creating signed URL:', error);
            return null;
        }
        return data.signedUrl;
    },

    async getStorageUsed() {
        if (!auth.client) return '0 MB';

        const user = await auth.getUser();
        if (!user) return '0 MB';
        // Reuse listFiles logic (which handles userId) but we need to call list directly to get metadata if we want raw access, 
        // or just use this.listFiles() if it returns size info. 
        // listFiles returns mapped objects with formatted size. 
        // Better to query Supabase again to be precise or parse the formatted strings.
        // Let's query Supabase directly using listFiles logic.

        const userId = user.id;
        const { data, error } = await auth.client
            .storage
            .from(BUCKET_NAME)
            .list(userId + '/', { limit: 1000 });

        if (error) {
            console.error('Error calculating storage used:', error);
            return '0 MB';
        }

        const totalBytes = data.reduce((acc, file) => {
            return acc + (file.metadata ? file.metadata.size : 0);
        }, 0);

        // Convert key units
        if (totalBytes > 1024 * 1024 * 1024) {
            return (totalBytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
        } else {
            return (totalBytes / (1024 * 1024)).toFixed(2) + ' MB';
        }
    },

    async getUserUploadCount() {
        if (!auth.client) return 0;

        const user = await auth.getUser();
        if (!user) return 0;
        const userId = user.id;

        const { data, error } = await auth.client
            .storage
            .from(BUCKET_NAME)
            .list(userId + '/', { limit: 1000 });

        if (error) {
            console.error('Error counting files:', error);
            return 0;
        }

        return data.length;
    }
};
