export class Hero {
  constructor() {
    this.init();
  }

  async init() {
    const heroContainer = document.querySelector('#hero-container');
    if (!heroContainer) return;

    try {
      const response = await fetch('src/components/Hero.html');
      const html = await response.text();
      heroContainer.innerHTML = html;

      const identifyBtn = heroContainer.querySelector('#hero-identify-btn');
      if (identifyBtn) {
        identifyBtn.addEventListener('click', (e) => {
          e.preventDefault();
          if (window.openIdentifyModal) {
            window.openIdentifyModal();
          } else {
            // Fallback if modal not loaded
            window.location.hash = '#identify';
          }
        });
      }
    } catch (error) {
      console.error('Error loading hero:', error);
    }
  }
}
