import { loadComponent } from '../../scripts/utils.js';
import { auth } from '../../scripts/auth.js';

export async function SettingsLogic() {
    const component = await loadComponent('src/components/settings/SettingsLayout.html');

    // --- Theme Logic ---
    const themeBtns = component.querySelectorAll('.theme-btn');

    // Initialize active state
    const currentTheme = localStorage.getItem('theme') || 'auto';
    themeBtns.forEach(btn => {
        if (btn.dataset.theme === currentTheme) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });

    themeBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const theme = btn.dataset.theme;

            // Update UI
            themeBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            // Apply Theme
            if (theme === 'auto') {
                localStorage.removeItem('theme');
                if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
                    document.documentElement.setAttribute('data-theme', 'dark');
                } else {
                    document.documentElement.setAttribute('data-theme', 'light');
                }
            } else {
                localStorage.setItem('theme', theme);
                document.documentElement.setAttribute('data-theme', theme);
            }
        });
    });

    // --- Account Logic ---
    const user = await auth.getUser();
    if (user) {
        const emailInput = component.querySelector('input[type="email"]');
        if (emailInput) emailInput.value = user.email;
    }

    // Logout
    const logoutBtn = component.querySelector('#btn-logout');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', async () => {
            await auth.signOut();
            window.location.href = 'index.html'; // Clean redirect
        });
    }

    // Change Password (Mock/Placeholder)
    const changePassBtn = component.querySelector('#btn-change-password');
    if (changePassBtn) {
        changePassBtn.addEventListener('click', () => {
            alert('Password reset link sent to your email.');
            // In a real app: await auth.resetPasswordForEmail(user.email);
        });
    }

    // Delete Account (Mock/Placeholder)
    const deleteAccountBtn = component.querySelector('#btn-delete-account');
    if (deleteAccountBtn) {
        deleteAccountBtn.addEventListener('click', () => {
            const confirmed = confirm('Are you sure you want to delete your account? This action cannot be undone.');
            if (confirmed) {
                alert('Account deletion request submitted.');
            }
        });
    }

    return component;
}
