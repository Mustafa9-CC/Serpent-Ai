import { loadComponent } from '../../scripts/utils.js';
import { auth } from '../../scripts/auth.js';

export async function ProfilePanel() {
    const component = await loadComponent('src/components/dashboard/ProfilePanel.html');

    const { storage } = await import('../../scripts/storage.js');

    const updateProfileDisplay = async () => {
        const user = await auth.getUser();
        if (user) {
            const name = user.user_metadata?.full_name || user.email.split('@')[0];
            const bio = user.user_metadata?.bio || 'Data Scientist | AI Enthusiast';

            component.querySelector('.profile-name').textContent = name;
            component.querySelector('.profile-email').textContent = user.email;
            component.querySelector('.profile-bio').textContent = bio;

            const avatarEl = component.querySelector('.profile-avatar-large');
            const avatarUrl = user.user_metadata?.avatar_url;

            if (avatarUrl) {
                if (avatarUrl.startsWith('http')) {
                    avatarEl.innerHTML = `<img src="${avatarUrl}" alt="${name}" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">`;
                } else {
                    const signedUrl = await storage.getSignedUrl(avatarUrl);
                    if (signedUrl) {
                        avatarEl.innerHTML = `<img src="${signedUrl}" alt="${name}" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">`;
                    } else {
                        avatarEl.textContent = name.charAt(0).toUpperCase();
                    }
                }
            } else {
                avatarEl.textContent = name.charAt(0).toUpperCase();
            }
        }
    };

    await updateProfileDisplay();

    // Edit Profile Button (Navigates to Full Profile Page)
    const editBtn = component.querySelector('.btn-outline');
    if (editBtn) {
        editBtn.textContent = 'View Profile'; // Update text to reflect action
        editBtn.addEventListener('click', async () => {
            const app = document.getElementById('app');
            const { Profile } = await import('../../pages/Profile.js');
            const profilePage = await Profile();
            app.innerHTML = '';
            app.appendChild(profilePage);
        });
    }

    // Listen for updates
    window.addEventListener('profile-updated', updateProfileDisplay);

    return component;
}
