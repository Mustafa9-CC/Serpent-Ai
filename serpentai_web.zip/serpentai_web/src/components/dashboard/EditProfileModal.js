import { loadComponent } from '../../scripts/utils.js';
import { auth } from '../../scripts/auth.js';

export async function EditProfileModal() {
    const component = await loadComponent('src/components/dashboard/EditProfileModal.html');

    const modal = component;
    const form = component.querySelector('#edit-profile-form');
    const closeBtn = component.querySelector('.close-modal');
    const cancelBtn = component.querySelector('#cancel-edit-profile');
    const nameInput = component.querySelector('#profile-name');
    const bioInput = component.querySelector('#profile-bio');

    // Open Modal Function
    window.openEditProfileModal = async () => {
        const user = await auth.getUser();
        if (user && user.user_metadata) {
            nameInput.value = user.user_metadata.full_name || '';
            bioInput.value = user.user_metadata.bio || '';
        }
        modal.classList.remove('hidden');
    };

    // Close Modal Function
    const closeModal = () => {
        modal.classList.add('hidden');
    };

    closeBtn.addEventListener('click', closeModal);
    cancelBtn.addEventListener('click', closeModal);

    // Close on click outside
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            closeModal();
        }
    });

    // Handle Form Submission
    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const updates = {
            full_name: nameInput.value,
            bio: bioInput.value
        };

        const { error } = await auth.updateProfile(updates);

        if (error) {
            alert('Error updating profile: ' + error.message);
        } else {
            closeModal();
            // Refresh Profile Panel
            window.dispatchEvent(new CustomEvent('profile-updated'));
        }
    });

    return component;
}
