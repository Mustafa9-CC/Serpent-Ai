import { loadComponent } from '../../scripts/utils.js';
import { auth } from '../../scripts/auth.js';
export async function Sidebar(activePage = 'dashboard') {
    const component = await loadComponent('src/components/dashboard/Sidebar.html');
    const { storage } = await import('../../scripts/storage.js');

    // Update User Info
    const user = await auth.getUser();
    if (user) {
        const avatar = component.querySelector('.avatar');
        const userName = component.querySelector('.user-name');

        if (userName) userName.textContent = user.email.split('@')[0];

        if (avatar) {
            const avatarUrl = user.user_metadata?.avatar_url;
            if (avatarUrl) {
                if (avatarUrl.startsWith('http')) {
                    avatar.innerHTML = `<img src="${avatarUrl}" alt="Avatar" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">`;
                } else {
                    const signedUrl = await storage.getSignedUrl(avatarUrl);
                    if (signedUrl) avatar.innerHTML = `<img src="${signedUrl}" alt="Avatar" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">`;
                }
            } else {
                avatar.textContent = user.email.charAt(0).toUpperCase();
            }
        }
    }

    // Set Active State
    const navItems = component.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        if (item.getAttribute('data-page') === activePage) {
            item.classList.add('active');
        } else {
            item.classList.remove('active');
        }
    });

    // Navigation Logic
    navItems.forEach(item => {
        item.addEventListener('click', async (e) => {
            e.preventDefault();
            const page = item.getAttribute('data-page');

            // Visual update
            navItems.forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');

            // Navigation
            const app = document.getElementById('app');

            if (page === 'dashboard') {
                const { Dashboard } = await import('../../pages/Dashboard.js');
                const dashboardPage = await Dashboard();
                app.innerHTML = '';
                app.appendChild(dashboardPage);
            } else if (page === 'identify') {
                const { Identify } = await import('../../pages/Identify.js');
                const identifyPage = await Identify();
                app.innerHTML = '';
                app.appendChild(identifyPage);
            } else if (page === 'questionnaire') {
                const { IdentifyQuestionnaire } = await import('../../pages/IdentifyQuestionnaire.js');
                const quizPage = await IdentifyQuestionnaire();
                app.innerHTML = '';
                app.appendChild(quizPage);
            } else if (page === 'database') {
                const { Database } = await import('../../pages/Database.js');
                const databasePage = await Database();
                app.innerHTML = '';
                app.appendChild(databasePage);
            } else if (page === 'emergency') {
                const { Emergency } = await import('../../pages/Emergency.js');
                const emergencyPage = await Emergency();
                app.innerHTML = '';
                app.appendChild(emergencyPage);
            } else if (page === 'settings') {
                const { Settings } = await import('../../pages/Settings.js');
                const settingsPage = await Settings();
                app.innerHTML = '';
                app.appendChild(settingsPage);
            } else if (page === 'activity') {
                const { Activity } = await import('../../pages/Activity.js');
                const activityPage = await Activity();
                app.innerHTML = '';
                app.appendChild(activityPage);
            } else if (page === 'profile') {
                const { Profile } = await import('../../pages/Profile.js');
                const profilePage = await Profile();
                app.innerHTML = '';
                app.appendChild(profilePage);
            }

            // Close sidebar on mobile after navigation
            if (window.innerWidth <= 1024) {
                component.classList.remove('open');
            }
        });
    });

    // Toggle Logic
    const toggleBtn = component.querySelector('#sidebar-toggle');
    const sidebar = component; // The component itself is the sidebar <aside> element

    if (toggleBtn) {
        toggleBtn.addEventListener('click', () => {
            // Close the sidebar
            sidebar.classList.remove('open');

            // Hide overlay if it exists
            const overlay = document.querySelector('.sidebar-overlay');
            if (overlay) {
                overlay.style.display = 'none';
            }
        });
    }

    // Logo Click Logic (Redirect to Landing)
    const logo = component.querySelector('.logo');
    if (logo) {
        logo.style.cursor = 'pointer';
        logo.addEventListener('click', () => {
            window.location.hash = '';
        });
    }

    // Mini Profile Click Logic
    const miniProfile = component.querySelector('.user-mini-profile');
    if (miniProfile) {
        miniProfile.style.cursor = 'pointer';
        miniProfile.addEventListener('click', async () => {
            // Visual update for nav items (deselect all)
            navItems.forEach(nav => nav.classList.remove('active'));

            const app = document.getElementById('app');
            const { Profile } = await import('../../pages/Profile.js');
            const profilePage = await Profile();
            app.innerHTML = '';
            app.appendChild(profilePage);

            // Close sidebar on mobile
            if (window.innerWidth <= 1024) {
                component.classList.remove('open');
            }
        });
    }

    return component;
}
