import { loadComponent } from '../../scripts/utils.js';
import { storage } from '../../scripts/storage.js';

export async function UploadManager() {
    const component = await loadComponent('src/components/dashboard/UploadManager.html');
    const grid = component.querySelector('.uploads-grid');
    const template = component.querySelector('#upload-item-template');
    const uploadBtn = component.querySelector('#upload-btn');
    const fileInput = component.querySelector('#file-input');
    const dropZone = component.querySelector('#drop-zone');

    // Modal Elements
    const modal = component.querySelector('#preview-modal');
    const modalImg = component.querySelector('#preview-image');
    const closeModal = component.querySelector('.close-modal');

    const openPreview = async (fileId, fileName) => {
        // Fetch signed URL
        const signedUrl = await storage.getSignedUrl(fileId);
        if (signedUrl) {
            modalImg.src = signedUrl;
            modal.classList.remove('hidden');
        } else {
            console.error('Could not get signed URL for preview');
        }
    };

    const closePreview = () => {
        modal.classList.add('hidden');
        modalImg.src = '';
    };

    closeModal.addEventListener('click', closePreview);
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            closePreview();
        }
    });

    const renderFiles = async () => {
        grid.innerHTML = '<p style="grid-column: 1/-1; text-align: center; opacity: 0.5;">Loading files...</p>';
        const files = await storage.listFiles();
        grid.innerHTML = '';

        if (files.length === 0) {
            grid.innerHTML = '<p style="grid-column: 1/-1; text-align: center; opacity: 0.5;">No files uploaded yet.</p>';
            return;
        }

        files.forEach(file => {
            const clone = template.content.cloneNode(true);

            clone.querySelector('.file-name').textContent = file.name;
            clone.querySelector('.file-size').textContent = file.size;
            clone.querySelector('.file-date').textContent = file.date;

            // Click listener for preview
            const item = clone.querySelector('.upload-item');
            item.addEventListener('click', () => {
                const isImage = ['JPG', 'JPEG', 'PNG', 'GIF', 'WEBP', 'BMP'].includes(file.type.toUpperCase());
                if (isImage) {
                    openPreview(file.id, file.name);
                }
            });

            const deleteBtn = clone.querySelector('.btn-delete');
            deleteBtn.addEventListener('click', async (e) => {
                e.stopPropagation(); // Prevent opening preview when clicking delete
                if (confirm(`Delete ${file.name}?`)) {
                    deleteBtn.disabled = true;
                    deleteBtn.style.opacity = '0.5';
                    const success = await storage.deleteFile(file.id);
                    if (success) {
                        renderFiles(); // Re-render
                        window.dispatchEvent(new CustomEvent('profile-updated')); // Notify others
                        window.dispatchEvent(new CustomEvent('storage-updated')); // Notify stats
                    } else {
                        alert('Failed to delete file.');
                        deleteBtn.disabled = false;
                        deleteBtn.style.opacity = '1';
                    }
                }
            });

            grid.appendChild(clone);
        });
    };

    // Upload Logic
    const handleUpload = async (file) => {
        if (!file) return;

        uploadBtn.disabled = true;
        uploadBtn.textContent = 'Uploading...';

        await storage.uploadFile(file);

        uploadBtn.disabled = false;
        uploadBtn.textContent = 'Upload New';
        renderFiles();
        window.dispatchEvent(new CustomEvent('storage-updated')); // Notify stats
    };

    // Button Click
    uploadBtn.addEventListener('click', () => {
        fileInput.click();
    });

    // File Input Change
    fileInput.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
            handleUpload(e.target.files[0]);
        }
    });

    // Drag & Drop
    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.style.borderColor = 'var(--primary)';
        dropZone.style.backgroundColor = 'rgba(0, 179, 126, 0.05)';
    });

    dropZone.addEventListener('dragleave', (e) => {
        e.preventDefault();
        dropZone.style.borderColor = '';
        dropZone.style.backgroundColor = '';
    });

    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.style.borderColor = '';
        dropZone.style.backgroundColor = '';

        if (e.dataTransfer.files.length > 0) {
            handleUpload(e.dataTransfer.files[0]);
        }
    });

    await renderFiles();

    return component;
}
