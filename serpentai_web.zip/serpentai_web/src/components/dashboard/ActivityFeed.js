import { loadComponent } from '../../scripts/utils.js';
import { scanHistory } from '../../scripts/scanHistory.js';
import { auth } from '../../scripts/auth.js';

export async function ActivityFeed() {
    const component = await loadComponent('src/components/dashboard/ActivityFeed.html');
    const list = component.querySelector('.feed-list');
    const template = component.querySelector('#feed-item-template');

    // Import storage dynamically
    const { storage } = await import('../../scripts/storage.js');

    const addFeedItem = (item, prepend = false) => {
        const clone = template.content.cloneNode(true);

        clone.querySelector('.feed-user').textContent = item.user;
        clone.querySelector('.feed-action').textContent = item.action;
        clone.querySelector('.feed-target').textContent = item.target;

        // Format time
        const timeStr = new Date(item.time).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
        clone.querySelector('.feed-time').textContent = timeStr;

        if (prepend) {
            list.prepend(clone.firstElementChild);
        } else {
            list.appendChild(clone);
        }
    };

    const fetchActivity = async () => {
        const user = await auth.getUser();
        const userName = user ? (user.user_metadata?.full_name || user.email.split('@')[0]) : 'You';

        // 1. Fetch Uploads
        const files = await storage.listFiles();
        const uploads = files.map(file => ({
            type: 'upload',
            action: 'uploaded',
            target: file.name,
            time: new Date(file.created_at || file.date),
            timestamp: new Date(file.created_at || file.date).getTime(),
            user: userName
        }));

        // 2. Fetch Scans
        // We need the user ID for scan history
        const userId = user ? user.id : null;
        const scans = scanHistory.getScans(userId);
        const identifications = scans.map(scan => ({
            type: 'identification',
            action: 'identified',
            target: scan.prediction || 'Snake',
            time: new Date(scan.timestamp),
            timestamp: new Date(scan.timestamp).getTime(),
            user: userName
        }));

        // 3. Merge and Sort
        const allActivity = [...uploads, ...identifications].sort((a, b) => b.timestamp - a.timestamp);

        // 4. Render (Limit to top 5 for dashboard)
        list.innerHTML = '';
        if (allActivity.length === 0) {
            list.innerHTML = '<p style="text-align: center; opacity: 0.5; padding: 1rem;">No recent activity.</p>';
        } else {
            allActivity.slice(0, 5).forEach(item => addFeedItem(item));
        }
    };

    await fetchActivity();

    // Listen for updates
    window.addEventListener('scan-added', fetchActivity);
    window.addEventListener('profile-updated', fetchActivity);

    return component;
}
