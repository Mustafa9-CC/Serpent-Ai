import { loadComponent } from '../../scripts/utils.js';
import { mockStats } from '../../data/mockData.js';
import { scanHistory } from '../../scripts/scanHistory.js';

export async function StatsCards() {
    const component = await loadComponent('src/components/dashboard/StatsCards.html');
    const grid = component.querySelector('.stats-grid');
    const template = component.querySelector('#stat-card-template');

    // Get Real Data
    const { storage } = await import('../../scripts/storage.js');
    const totalUploads = await storage.getUserUploadCount();
    const storageUsed = await storage.getStorageUsed();

    // Update Mock Data with Real Values
    const stats = mockStats.map(stat => {
        if (stat.label === 'Total Uploads') {
            return {
                ...stat,
                value: totalUploads.toString(),
                change: 'All time'
            };
        }
        if (stat.label === 'Storage Used') {
            return {
                ...stat,
                value: storageUsed,
                change: 'Used'
            };
        }
        return stat;
    });

    stats.forEach(stat => {
        const clone = template.content.cloneNode(true);

        clone.querySelector('.stat-icon').textContent = stat.icon;
        clone.querySelector('.stat-label').textContent = stat.label;
        clone.querySelector('.stat-value').textContent = stat.value;

        const changeEl = clone.querySelector('.stat-change');
        changeEl.textContent = stat.change;
        changeEl.classList.add(stat.change.startsWith('+') ? 'positive' : 'negative');

        grid.appendChild(clone);
    });

    const updateStats = async () => {
        const newTotal = await storage.getUserUploadCount();
        const newStorage = await storage.getStorageUsed();

        // Find the Total Uploads card and update it
        const cards = grid.querySelectorAll('.stat-card');
        cards.forEach(card => {
            const label = card.querySelector('.stat-label').textContent;
            if (label === 'Total Uploads') {
                card.querySelector('.stat-value').textContent = newTotal;
            }
            if (label === 'Storage Used') {
                card.querySelector('.stat-value').textContent = newStorage;
            }
        });
    };

    // Listen for new scans/uploads to update count dynamically
    window.addEventListener('scan-added', updateStats);
    window.addEventListener('storage-updated', updateStats); // Listen for updates

    return component;
}
