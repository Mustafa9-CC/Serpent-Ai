import { loadComponent } from '../../scripts/utils.js';
import { auth } from '../../scripts/auth.js';

export async function DashboardHeader() {
    const component = await loadComponent('src/components/dashboard/DashboardHeader.html');

    // Theme Toggle
    const themeToggle = component.querySelector('#theme-toggle');
    const currentTheme = document.documentElement.getAttribute('data-theme');
    themeToggle.textContent = currentTheme === 'light' ? '🌙' : '☀️';

    themeToggle.addEventListener('click', () => {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        themeToggle.textContent = newTheme === 'light' ? '🌙' : '☀️';
    });

    // User Avatar
    const user = await auth.getUser();
    const { storage } = await import('../../scripts/storage.js');

    if (user) {
        const avatar = component.querySelector('.avatar');
        const avatarUrl = user.user_metadata?.avatar_url;

        if (avatarUrl) {
            if (avatarUrl.startsWith('http')) {
                avatar.innerHTML = `<img src="${avatarUrl}" alt="User" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">`;
            } else {
                const signedUrl = await storage.getSignedUrl(avatarUrl);
                if (signedUrl) {
                    avatar.innerHTML = `<img src="${signedUrl}" alt="User" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">`;
                } else {
                    avatar.textContent = user.email.charAt(0).toUpperCase();
                }
            }
        } else {
            avatar.textContent = user.email.charAt(0).toUpperCase();
        }
    }

    // Dropdown
    const avatarBtn = component.querySelector('.avatar-btn');
    const dropdownMenu = component.querySelector('.dropdown-menu');

    avatarBtn.addEventListener('click', () => {
        dropdownMenu.classList.toggle('hidden');
    });

    // Profile Link Logic
    const profileLink = component.querySelector('.dropdown-item:first-child'); // Assuming Profile is first
    if (profileLink) {
        profileLink.addEventListener('click', async (e) => {
            e.preventDefault();
            dropdownMenu.classList.add('hidden');

            const app = document.getElementById('app');
            const { Profile } = await import('../../pages/Profile.js');
            const profilePage = await Profile();
            app.innerHTML = '';
            app.appendChild(profilePage);

            // Update Sidebar Active State
            const sidebarItems = document.querySelectorAll('.nav-item');
            sidebarItems.forEach(item => item.classList.remove('active'));
            // Ideally find the profile link in sidebar if it exists (it's the mini profile, not a nav item usually, but we can leave it or highlight nothing)
        });
    }

    // Close dropdown on outside click
    document.addEventListener('click', (e) => {
        if (!avatarBtn.contains(e.target) && !dropdownMenu.contains(e.target)) {
            dropdownMenu.classList.add('hidden');
        }
    });

    // Logout
    const logoutBtn = component.querySelector('#logout-btn');
    logoutBtn.addEventListener('click', async () => {
        await auth.signOut();
        window.location.href = 'index.html'; // Redirect to home/landing
    });

    // Mobile Menu Toggle (Sidebar)
    const menuToggle = component.querySelector('.menu-toggle');
    menuToggle.addEventListener('click', () => {
        const sidebar = document.querySelector('.sidebar');
        if (sidebar) {
            sidebar.classList.toggle('open');

            // Optional: Add overlay if not present
            let overlay = document.querySelector('.sidebar-overlay');
            if (!overlay) {
                overlay = document.createElement('div');
                overlay.className = 'sidebar-overlay';
                overlay.style.cssText = `
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100vw;
                    height: 100vh;
                    background: rgba(0,0,0,0.5);
                    z-index: 99;
                    display: none;
                `;
                document.body.appendChild(overlay);

                overlay.addEventListener('click', () => {
                    sidebar.classList.remove('open');
                    overlay.style.display = 'none';
                });
            }

            if (sidebar.classList.contains('open')) {
                overlay.style.display = 'block';
            } else {
                overlay.style.display = 'none';
            }
        }
    });

    return component;
}
