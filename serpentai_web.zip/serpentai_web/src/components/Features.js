export class Features {
  constructor() {
    this.init();
  }

  async init() {
    const featuresContainer = document.querySelector('#features-container');
    if (!featuresContainer) return;

    try {
      const response = await fetch('src/components/Features.html');
      const html = await response.text();
      featuresContainer.innerHTML = html;
    } catch (error) {
      console.error('Error loading features:', error);
    }
  }
}
