import { loadComponent } from '../../scripts/utils.js';
import { scanHistory } from '../../scripts/scanHistory.js';
import { auth } from '../../scripts/auth.js';

export async function ActivityTimeline() {
    const component = await loadComponent('src/components/activity/ActivityLayout.html');
    const timelineContainer = component.querySelector('#timeline-container');
    const itemTemplate = await loadComponent('src/components/activity/TimelineItem.html');
    const loadingSkeleton = component.querySelector('#loading-skeleton');
    const filterBtns = component.querySelectorAll('.filter-btn');

    // Import storage dynamically to avoid circular dependencies if any
    const { storage } = await import('../../scripts/storage.js');

    let currentFilter = 'all';
    let displayedItems = 0;
    const ITEMS_PER_PAGE = 10;
    let allActivity = [];

    // --- Data Fetching ---
    const fetchActivity = async () => {
        const user = await auth.getUser();
        const userName = user ? (user.user_metadata?.full_name || user.email.split('@')[0]) : 'You';

        // 1. Fetch Uploads
        const files = await storage.listFiles();
        const uploads = files.map(file => ({
            type: 'upload',
            action: 'uploaded',
            target: file.name,
            time: new Date(file.created_at || file.date), // Use created_at if available
            timestamp: new Date(file.created_at || file.date).getTime(),
            user: userName,
            details: `${file.size} • ${file.type}`
        }));

        // 2. Fetch Scans
        const scans = scanHistory.getScans();
        const identifications = scans.map(scan => ({
            type: 'identification',
            action: 'identified',
            target: scan.prediction || 'Snake', // Assuming scan object has prediction
            time: new Date(scan.timestamp),
            timestamp: new Date(scan.timestamp).getTime(),
            user: userName,
            details: `Confidence: ${scan.confidence || 'N/A'}`
        }));

        // 3. Merge and Sort
        allActivity = [...uploads, ...identifications].sort((a, b) => b.timestamp - a.timestamp);
    };

    // --- Helper Functions ---

    const getIconForAction = (type) => {
        if (type === 'upload') return '📤';
        if (type === 'identification') return '🐍';
        if (type === 'deletion') return '🗑️';
        return '📝';
    };

    const formatDate = (date) => {
        if (!date) return 'Unknown';
        const d = new Date(date);
        const today = new Date();
        const yesterday = new Date(today);
        yesterday.setDate(yesterday.getDate() - 1);

        if (d.toDateString() === today.toDateString()) return 'Today';
        if (d.toDateString() === yesterday.toDateString()) return 'Yesterday';
        return d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
    };

    const formatTime = (date) => {
        if (!date) return '';
        return new Date(date).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    };

    const createTimelineItem = (item) => {
        const clone = itemTemplate.cloneNode(true);

        const icon = clone.querySelector('.timeline-icon');
        icon.textContent = getIconForAction(item.type);

        // Color code icon border based on type
        if (item.type === 'upload') icon.style.borderColor = 'var(--primary)';
        if (item.type === 'identification') icon.style.borderColor = '#fb8500';
        if (item.type === 'deletion') icon.style.borderColor = 'var(--danger)';

        clone.querySelector('.item-time').textContent = formatTime(item.time);

        const badge = clone.querySelector('.item-type-badge');
        badge.textContent = item.type;
        badge.classList.add(`badge-${item.type}`);

        clone.querySelector('.item-description').textContent = `${item.user} ${item.action} ${item.target}`;

        // Add details if available
        if (item.details) {
            const detailsEl = document.createElement('div');
            detailsEl.style.fontSize = '0.85rem';
            detailsEl.style.color = 'var(--text-secondary)';
            detailsEl.style.marginTop = '0.25rem';
            detailsEl.textContent = item.details;
            clone.querySelector('.timeline-content').appendChild(detailsEl);
        }

        clone.querySelector('.user-avatar').textContent = item.user.charAt(0).toUpperCase();
        clone.querySelector('.user-name').textContent = item.user;

        return clone;
    };

    const renderTimeline = (append = false) => {
        if (!append) {
            timelineContainer.innerHTML = '<div class="timeline-line"></div>';
            displayedItems = 0;
        }

        const filtered = allActivity.filter(item => {
            if (currentFilter === 'all') return true;
            return item.type === currentFilter;
        });

        const itemsToRender = filtered.slice(displayedItems, displayedItems + ITEMS_PER_PAGE);

        if (itemsToRender.length === 0 && !append) {
            timelineContainer.innerHTML += '<p style="padding: 2rem; text-align: center; color: var(--text-secondary);">No activity found.</p>';
            loadingSkeleton.classList.add('hidden');
            return;
        }

        let lastDate = null;
        // Check if we need to add a date header for the first item if appending
        if (append && displayedItems > 0) {
            const lastItem = filtered[displayedItems - 1];
            if (lastItem) lastDate = formatDate(lastItem.time);
        }

        itemsToRender.forEach(item => {
            const dateGroup = formatDate(item.time);

            if (dateGroup !== lastDate) {
                // Check if header already exists (for append scenarios, though we usually just append)
                // Ideally we check the last element in container
                const header = document.createElement('div');
                header.className = 'date-header';
                header.innerHTML = `<span>${dateGroup}</span>`;
                timelineContainer.appendChild(header);
                lastDate = dateGroup;
            }

            const el = createTimelineItem(item);
            timelineContainer.appendChild(el);
        });

        displayedItems += itemsToRender.length;

        // Hide skeleton if no more items
        if (displayedItems >= filtered.length) {
            loadingSkeleton.classList.add('hidden');
        } else {
            loadingSkeleton.classList.remove('hidden');
        }
    };

    // --- Event Listeners ---

    // Filters
    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            currentFilter = btn.dataset.filter;
            renderTimeline(false);
        });
    });

    // Infinite Scroll
    const handleScroll = () => {
        const { scrollTop, scrollHeight, clientHeight } = document.documentElement;

        if (scrollTop + clientHeight >= scrollHeight - 100) {
            // Only load more if we have more to show
            const filteredCount = allActivity.filter(item => currentFilter === 'all' || item.type === currentFilter).length;
            if (displayedItems < filteredCount) {
                loadingSkeleton.classList.remove('hidden');
                // Debounce or just wait a bit
                setTimeout(() => {
                    renderTimeline(true);
                }, 500);
            }
        }
    };

    window.addEventListener('scroll', handleScroll);

    // Initial Load
    await fetchActivity();
    renderTimeline();

    // Listen for updates
    window.addEventListener('scan-added', async () => {
        await fetchActivity();
        renderTimeline(false);
    });

    // We might want to listen for uploads too if we add an event for it
    window.addEventListener('profile-updated', async () => {
        await fetchActivity();
        renderTimeline(false);
    });

    component.disconnectedCallback = () => {
        window.removeEventListener('scroll', handleScroll);
    };

    return component;
}
