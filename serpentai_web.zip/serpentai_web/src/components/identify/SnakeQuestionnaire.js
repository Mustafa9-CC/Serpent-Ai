import { loadComponent } from '../../scripts/utils.js';
import { snakes } from '../../data/snakes.js';

// Knowledge Base for Matching
// Maps snake IDs to feature keys
const snakeFeatures = {
    'cobra': {
        colors: ['black', 'brown', 'mixed'],
        patterns: ['solid', 'spectacle'], // Spectacle mark on hood
        head: ['hooded', 'round'],
        body: ['moderate'],
        length: ['medium', 'large'],
        environment: ['urban', 'field', 'forest'],
        behavior: ['hooding', 'aggressive']
    },
    'russells-viper': {
        colors: ['brown', 'yellow', 'mixed'],
        patterns: ['spots', 'circles'], // Chain pattern
        head: ['triangular'],
        body: ['thick'],
        length: ['medium'],
        environment: ['field', 'scrub'],
        behavior: ['hissing', 'aggressive', 'coiled']
    },
    'krait': {
        colors: ['black', 'blue', 'mixed'],
        patterns: ['bands'], // White bands
        head: ['round'],
        body: ['moderate'],
        length: ['medium'],
        environment: ['urban', 'field'],
        behavior: ['calm', 'nocturnal']
    },
    'rat-snake': {
        colors: ['brown', 'yellow', 'black', 'green'],
        patterns: ['solid', 'checkered'],
        head: ['round', 'narrow'],
        body: ['moderate'],
        length: ['large', 'medium'],
        environment: ['urban', 'field', 'forest'],
        behavior: ['fast', 'agile']
    },
    'python': {
        colors: ['brown', 'mixed'],
        patterns: ['blotches', 'spots'],
        head: ['triangular', 'broad'],
        body: ['thick', 'heavy'],
        length: ['large'],
        environment: ['forest', 'rocky', 'water'],
        behavior: ['slow', 'calm']
    },
    'saw-scaled-viper': {
        colors: ['brown', 'red', 'mixed'],
        patterns: ['zigzag', 'spots'],
        head: ['triangular'],
        body: ['moderate'],
        length: ['small'],
        environment: ['rocky', 'dry'],
        behavior: ['hissing', 'coiled', 'sidewinding']
    },
    'king-cobra': {
        colors: ['brown', 'green', 'mixed'],
        patterns: ['bands', 'solid'],
        head: ['hooded'],
        body: ['moderate'],
        length: ['large'],
        environment: ['forest'],
        behavior: ['hooding', 'aggressive']
    },
    'green-vine-snake': {
        colors: ['green'],
        patterns: ['solid'],
        head: ['pointed', 'narrow'],
        body: ['thin'],
        length: ['medium', 'large'],
        environment: ['tree', 'bush'],
        behavior: ['calm', 'still']
    }
};

const questions = [
    {
        id: 'colors',
        title: "What was the snake's primary color?",
        options: [
            { label: 'Green', value: 'green', icon: '🟢' },
            { label: 'Brown / Earth', value: 'brown', icon: '🟤' },
            { label: 'Black / Dark', value: 'black', icon: '⚫' },
            { label: 'Red / Orange', value: 'red', icon: '🔴' },
            { label: 'Yellow / Pale', value: 'yellow', icon: '🟡' },
            { label: 'Mixed / Patterned', value: 'mixed', icon: '🎨' }
        ]
    },
    {
        id: 'patterns',
        title: "Did the snake have any patterns?",
        options: [
            { label: 'Solid / Plain', value: 'solid', icon: 'mmm' },
            { label: 'Stripes (Lengthwise)', value: 'stripes', icon: '|||' },
            { label: 'Bands / Rings', value: 'bands', icon: '≣' },
            { label: 'Spots / Dots', value: 'spots', icon: '::' },
            { label: 'Zigzag / Checkered', value: 'zigzag', icon: '〰' }
        ]
    },
    {
        id: 'head',
        title: "What shape was the head?",
        options: [
            { label: 'Round / Oval', value: 'round', icon: '●' },
            { label: 'Triangular / Broad', value: 'triangular', icon: '▲' },
            { label: 'Hooded (Flared)', value: 'hooded', icon: '⛱' },
            { label: 'Pointed / Narrow', value: 'pointed', icon: 'V' }
        ]
    },
    {
        id: 'body',
        title: "How thick was the body?",
        options: [
            { label: 'Very Thin (Pencil)', value: 'thin', icon: '➖' },
            { label: 'Moderate', value: 'moderate', icon: '▭' },
            { label: 'Thick / Heavy', value: 'thick', icon: '▅' }
        ]
    },
    {
        id: 'length',
        title: "About how long was it?",
        options: [
            { label: 'Small (< 1 ft)', value: 'small', icon: '📏' },
            { label: 'Medium (1 - 4 ft)', value: 'medium', icon: '📏' },
            { label: 'Large (> 4 ft)', value: 'large', icon: '📏' }
        ]
    },
    {
        id: 'environment',
        title: "Where did you see it?",
        options: [
            { label: 'Forest / Jungle', value: 'forest', icon: '🌳' },
            { label: 'Near Water', value: 'water', icon: '💧' },
            { label: 'Open Field / Grass', value: 'field', icon: '🌾' },
            { label: 'Urban / House', value: 'urban', icon: '🏠' },
            { label: 'Rocky / Dry', value: 'rocky', icon: '🪨' },
            { label: 'Tree / Bush', value: 'tree', icon: '🌿' }
        ]
    }
];

export async function SnakeQuestionnaire() {
    const component = await loadComponent('src/components/identify/SnakeQuestionnaire.html');

    // Inject CSS
    if (!document.querySelector('#questionnaire-styles')) {
        const link = document.createElement('link');
        link.id = 'questionnaire-styles';
        link.rel = 'stylesheet';
        link.href = 'src/components/identify/SnakeQuestionnaire.css';
        document.head.appendChild(link);
    }

    let currentStep = 0;
    const answers = {};

    // Elements
    const startScreen = component.querySelector('#start-screen');
    const questionView = component.querySelector('#question-view');
    const resultsView = component.querySelector('#results-view');

    const startBtn = component.querySelector('#start-btn');
    const nextBtn = component.querySelector('#next-btn');
    const prevBtn = component.querySelector('#prev-btn');
    const restartBtn = component.querySelector('#restart-btn');

    const cardContainer = component.querySelector('#card-container');
    const progressFill = component.querySelector('#progress-fill');
    const progressText = component.querySelector('#progress-text');
    const matchesGrid = component.querySelector('#matches-grid');

    // Navigation Logic
    startBtn.addEventListener('click', () => {
        startScreen.classList.add('hidden');
        questionView.classList.remove('hidden');
        renderStep(0);
    });

    nextBtn.addEventListener('click', () => {
        if (currentStep < questions.length - 1) {
            currentStep++;
            renderStep(currentStep);
        } else {
            finishQuestionnaire();
        }
    });

    prevBtn.addEventListener('click', () => {
        if (currentStep > 0) {
            currentStep--;
            renderStep(currentStep);
        }
    });

    restartBtn.addEventListener('click', () => {
        resultsView.classList.add('hidden');
        startScreen.classList.remove('hidden');
        currentStep = 0;
        // clear answers
        Object.keys(answers).forEach(k => delete answers[k]);
    });

    function renderStep(index) {
        currentStep = index;
        const q = questions[index];

        // Update Progress
        const percent = ((index + 1) / questions.length) * 100;
        progressFill.style.width = `${percent}%`;
        progressText.textContent = `Question ${index + 1} of ${questions.length}`;

        // Render Card
        cardContainer.innerHTML = '';
        const card = document.createElement('div');
        card.className = 'question-card';

        const title = document.createElement('h3');
        title.className = 'question-title';
        title.textContent = q.title;
        card.appendChild(title);

        const grid = document.createElement('div');
        grid.className = 'options-grid';

        q.options.forEach(opt => {
            const optEl = document.createElement('div');
            optEl.className = 'option-card';
            if (answers[q.id] === opt.value) {
                optEl.classList.add('selected');
            }

            optEl.innerHTML = `
                <div class="option-icon">${opt.icon}</div>
                <div class="option-label">${opt.label}</div>
            `;

            optEl.addEventListener('click', () => {
                // Select Logic
                grid.querySelectorAll('.option-card').forEach(c => c.classList.remove('selected'));
                optEl.classList.add('selected');

                answers[q.id] = opt.value;
                nextBtn.disabled = false;

                // Auto-advance after small delay if on mobile maybe? 
                // For now, let user click Continue to confirm
            });

            grid.appendChild(optEl);
        });

        card.appendChild(grid);
        cardContainer.appendChild(card);

        // Button States
        prevBtn.disabled = index === 0;
        nextBtn.disabled = !answers[q.id];

        if (index === questions.length - 1) {
            nextBtn.textContent = 'Finish';
        } else {
            nextBtn.textContent = 'Continue';
        }
    }

    function finishQuestionnaire() {
        questionView.classList.add('hidden');
        resultsView.classList.remove('hidden');

        const matches = calculateMatches(answers);
        renderResults(matches);
    }

    function calculateMatches(userAnswers) {
        // Simple scoring algorithm
        const scores = [];

        Object.keys(snakeFeatures).forEach(snakeId => {
            const features = snakeFeatures[snakeId];
            let score = 0;
            let maxScore = 0;

            // Check each answer
            Object.keys(userAnswers).forEach(key => {
                const userVal = userAnswers[key];
                const snakeVals = features[key]; // Array of valid values for this snake feature

                maxScore++; // Potential point

                if (snakeVals && snakeVals.includes(userVal)) {
                    score += 1; // Strict match
                } else if (snakeVals && snakeVals.includes('mixed')) {
                    score += 0.5; // Partial match if snake is mixed
                }
            });

            // Normalize score
            const percentage = maxScore > 0 ? (score / maxScore) : 0;

            // Get full snake data
            const snakeData = snakes.find(s => s.id === snakeId);
            if (snakeData) {
                scores.push({
                    ...snakeData,
                    matchScore: percentage
                });
            }
        });

        // Sort by score
        return scores.sort((a, b) => b.matchScore - a.matchScore).slice(0, 4);
    }

    function renderResults(matches) {
        matchesGrid.innerHTML = '';

        matches.forEach(snake => {
            // Only show if at least some compatibility (e.g. > 40%)
            // if (snake.matchScore < 0.4) return;

            const card = document.createElement('div');
            card.className = 'match-card';

            const confidence = Math.round(snake.matchScore * 100);

            // Venom badge styling
            const badgeClass = snake.venomous ? 'venomous' : 'non-venomous';
            const badgeText = snake.venomous ? (snake.dangerLevel === 'High' ? '⚠️ Highly Venomous' : '⚠ Venomous') : '🛡️ Non-Venomous';

            card.innerHTML = `
                <img src="${snake.image}" alt="${snake.commonName}" class="match-image">
                <div class="match-content">
                    <div class="match-header">
                        <div>
                            <h3 class="match-name">${snake.commonName}</h3>
                            <span class="scientific-name">${snake.scientificName}</span>
                        </div>
                        <div class="match-confidence">${confidence}% Match</div>
                    </div>
                    
                    <div class="venom-badge ${badgeClass}">
                        ${badgeText}
                    </div>
                    
                    <p class="text-secondary" style="margin-top: 1rem; font-size: 0.9rem; line-height: 1.4;">
                        ${snake.description.substring(0, 100)}...
                    </p>
                    
                    <button class="btn btn-outline" style="width: 100%; margin-top: 1rem;">View Details</button>
                    <!-- In a real app, this would open the detailed modal -->
                </div>
            `;

            const detailsBtn = card.querySelector('button');
            detailsBtn.addEventListener('click', () => {
                // To implement: Open details modal
                alert(`Details for ${snake.commonName}:\n\n${snake.description}\n\nBehavior: ${snake.behavior}`);
            });

            matchesGrid.appendChild(card);
        });

        if (matchesGrid.children.length === 0) {
            matchesGrid.innerHTML = `
                <div style="grid-column: 1/-1; text-align: center; padding: 2rem;">
                    <h3>No close matches found.</h3>
                    <p>Try adjusting your answers.</p>
                </div>
            `;
        }
    }

    return component;
}
