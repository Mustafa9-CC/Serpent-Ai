import { loadComponent } from '../../scripts/utils.js';

export async function IdentifyResult(data) {
    const component = await loadComponent('src/components/identify/IdentifyResult.html');

    if (data) {
        // Header
        component.querySelector('.species-name').textContent = `${data.name} (${data.scientific})`;
        component.querySelector('.confidence-badge').textContent = `${data.confidence}% Confidence`;

        const dangerEl = component.querySelector('.danger-level');
        const dangerText = component.querySelector('.danger-text');

        // Reset classes
        dangerEl.classList.remove('level-high', 'level-medium', 'level-low');

        if (data.danger === 'High') {
            dangerEl.classList.add('level-high');
            dangerText.textContent = 'Highly Venomous'; // Or use data.venom
        } else if (data.danger === 'Medium') {
            dangerEl.classList.add('level-medium');
            dangerText.textContent = 'Moderately Venomous';
        } else {
            dangerEl.classList.add('level-low');
            dangerText.textContent = 'Non-venomous';
        }

        // Info Grid (Assuming data doesn't have all these fields yet, we might need to adjust prompt or handle missing)
        // For now, let's try to map what we have or hide missing
        // We requested: name, scientific, venom, danger, confidence, description

        // We can add these to the prompt if we want them: Family, Habitat, Activity, Diet
        // For now, let's just update what we can and maybe hide others or leave generic

        const infoItems = component.querySelectorAll('.info-item');
        // 0: Family, 1: Habitat, 2: Activity, 3: Diet
        // If the API returns them, great. If not, we could hide or put "Unknown"

        // Let's update the prompt in gemini.js to ask for these if we want them.
        // For now, let's just update the description and safety.

        component.querySelector('.description-section p').textContent = data.description;

        // Safety (Generic based on danger)
        const safetyList = component.querySelector('.safety-list');
        if (data.danger === 'High') {
            safetyList.innerHTML = `
                <li>Keep a safe distance (at least 6 feet).</li>
                <li>Do not attempt to handle or provoke.</li>
                <li>If bitten, seek immediate medical attention.</li>
            `;
        } else {
            safetyList.innerHTML = `
                <li>Generally harmless, but do not provoke.</li>
                <li>Wash any bite wounds with soap and water.</li>
            `;
        }
    }

    return component;
}
