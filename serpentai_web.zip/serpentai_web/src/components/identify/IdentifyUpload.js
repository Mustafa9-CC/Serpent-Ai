import { loadComponent } from '../../scripts/utils.js';
import { IdentifyResult } from './IdentifyResult.js';

export async function IdentifyUpload() {
    const component = await loadComponent('src/components/identify/IdentifyUpload.html');

    const dropZone = component.querySelector('#drop-zone');
    const fileInput = component.querySelector('#file-input');
    const uploadBtn = component.querySelector('#upload-btn');
    const previewContainer = component.querySelector('#preview-container');
    const imagePreview = component.querySelector('#image-preview');
    const removeBtn = component.querySelector('#remove-btn');
    const processingOverlay = component.querySelector('#processing-overlay');
    const uploadContent = component.querySelector('#upload-content');
    const goToQuizBtn = component.querySelector('#go-to-quiz');

    if (goToQuizBtn) {
        goToQuizBtn.addEventListener('click', async (e) => {
            e.preventDefault();
            const app = document.getElementById('app');
            const { IdentifyQuestionnaire } = await import('../../pages/IdentifyQuestionnaire.js');
            const quizPage = await IdentifyQuestionnaire();
            app.innerHTML = '';
            app.appendChild(quizPage);
        });
    }

    // Drag & Drop
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, preventDefaults, false);
    });

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, highlight, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, unhighlight, false);
    });

    function highlight(e) {
        dropZone.classList.add('drag-over');
    }

    function unhighlight(e) {
        dropZone.classList.remove('drag-over');
    }

    dropZone.addEventListener('drop', handleDrop, false);

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        handleFiles(files);
    }

    // Button Click
    uploadBtn.addEventListener('click', () => {
        fileInput.click();
    });

    fileInput.addEventListener('change', function () {
        handleFiles(this.files);
    });

    function handleFiles(files) {
        if (files.length > 0) {
            const file = files[0];
            if (file.type.startsWith('image/')) {
                showPreview(file);
                simulateProcessing(file);
            } else {
                alert('Please upload an image file.');
            }
        }
    }

    function showPreview(file) {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onloadend = function () {
            imagePreview.src = reader.result;
            previewContainer.classList.remove('hidden');
        }
    }

    removeBtn.addEventListener('click', () => {
        previewContainer.classList.add('hidden');
        fileInput.value = '';
        imagePreview.src = '';
        // Also remove result if exists
        const existingResult = component.parentElement.querySelector('.result-card');
        if (existingResult) existingResult.remove();
    });

    function simulateProcessing(file) {
        processingOverlay.classList.remove('hidden');

        // Upload to Supabase
        import('../../scripts/storage.js').then(async ({ storage }) => {
            const uploadedFile = await storage.uploadFile(file);

            if (uploadedFile) {
                // Real AI Analysis with Gemini
                import('../../scripts/gemini.js').then(async ({ gemini }) => {
                    const analysisResult = await gemini.analyzeImage(file);

                    if (analysisResult.error) {
                        processingOverlay.classList.add('hidden');
                        alert(analysisResult.error);
                        return;
                    }

                    // Save to History
                    import('../../scripts/scanHistory.js').then(async ({ scanHistory }) => {
                        const { auth } = await import('../../scripts/auth.js');
                        const user = await auth.getUser();
                        const userId = user ? user.id : null;

                        if (userId) {
                            scanHistory.addScan({
                                image: uploadedFile.name,
                                species: analysisResult.name,
                                scientificName: analysisResult.scientific,
                                confidence: analysisResult.confidence,
                                dangerLevel: analysisResult.danger,
                                venomStatus: analysisResult.venom,
                                description: analysisResult.description
                            }, userId);

                            window.dispatchEvent(new CustomEvent('scan-added'));
                        }
                    });

                    processingOverlay.classList.add('hidden');

                    // Show Result
                    const { IdentifyResult } = await import('./IdentifyResult.js');
                    const resultComponent = await IdentifyResult(analysisResult);
                    // Note: IdentifyResult needs to be updated to accept data if it doesn't already

                    const parent = component.parentElement;
                    if (parent) {
                        const oldResult = parent.querySelector('.result-card');
                        if (oldResult) oldResult.remove();
                        parent.appendChild(resultComponent);
                    }
                });
            } else {
                processingOverlay.classList.add('hidden');
                alert('Upload failed. Please try again.');
            }
        });
    }

    // Camera Logic
    let stream = null;
    const cameraContainer = component.querySelector('#camera-container');
    const video = component.querySelector('#camera-feed');
    const canvas = component.querySelector('#camera-canvas');
    const captureBtn = component.querySelector('#capture-btn');
    const closeCameraBtn = component.querySelector('#close-camera-btn');

    async function startCamera() {
        try {
            stream = await navigator.mediaDevices.getUserMedia({
                video: { facingMode: 'environment' }
            });
            video.srcObject = stream;
            cameraContainer.classList.remove('hidden');
        } catch (err) {
            console.error("Error accessing camera:", err);
            alert("Could not access camera. Please allow camera permissions.");
        }
    }

    function stopCamera() {
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
            stream = null;
        }
        video.srcObject = null;
        cameraContainer.classList.add('hidden');
    }

    captureBtn.addEventListener('click', () => {
        if (!stream) return;

        // Set canvas dimensions to match video
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;

        // Draw video frame to canvas
        const ctx = canvas.getContext('2d');
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

        // Convert to blob/file
        canvas.toBlob(blob => {
            const file = new File([blob], "camera_capture.jpg", { type: "image/jpeg" });
            stopCamera();
            handleFiles([file]);
        }, 'image/jpeg', 0.95);
    });

    closeCameraBtn.addEventListener('click', stopCamera);

    // Auto-trigger based on action
    setTimeout(() => {
        const action = localStorage.getItem('identify_action');
        if (action) {
            localStorage.removeItem('identify_action'); // Clear flag

            if (action === 'upload') {
                fileInput.removeAttribute('capture');
                fileInput.click();
            } else if (action === 'camera') {
                // Try to start camera UI first
                if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
                    startCamera();
                } else {
                    // Fallback for older devices or if getUserMedia not supported
                    fileInput.setAttribute('capture', 'environment');
                    fileInput.click();
                    setTimeout(() => {
                        fileInput.removeAttribute('capture');
                    }, 1000);
                }
            }
        }
    }, 500); // Small delay to ensure component is fully mounted/visible

    return component;
}
