import { loadComponent } from '../../scripts/utils.js';

export async function IdentifyHistory() {
    const component = await loadComponent('src/components/identify/IdentifyHistory.html');

    const container = component.querySelector('#history-list-container');

    const renderHistory = async () => {
        const { scanHistory } = await import('../../scripts/scanHistory.js');
        const { storage } = await import('../../scripts/storage.js');

        const { auth } = await import('../../scripts/auth.js');
        const user = await auth.getUser();
        const userId = user ? user.id : null;

        const scans = scanHistory.getScans(userId);
        container.innerHTML = '';

        if (scans.length === 0) {
            container.innerHTML = '<p style="text-align: center; color: var(--text-secondary); padding: 1rem;">No recent scans</p>';
            return;
        }

        scans.forEach(scan => {
            const item = document.createElement('div');
            item.className = 'history-item';

            const imageUrl = storage.getPublicUrl(scan.image, userId);

            // Determine status class
            let statusClass = 'status-safe';
            if (scan.dangerLevel === 'High') statusClass = 'status-danger';
            if (scan.dangerLevel === 'Medium') statusClass = 'status-pending'; // Reusing pending color for medium

            // Format Date
            const date = new Date(scan.timestamp);
            const timeString = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            const dateString = date.toLocaleDateString();

            item.innerHTML = `
                <img src="${imageUrl}" alt="${scan.species}" class="history-thumb">
                <div class="history-info">
                    <h4>${scan.species}</h4>
                    <span class="history-date">${dateString}, ${timeString}</span>
                </div>
                <div class="history-status ${statusClass}">${scan.dangerLevel}</div>
            `;

            container.appendChild(item);
        });
    };

    renderHistory();

    // Listen for updates
    window.addEventListener('scan-added', renderHistory);

    return component;
}
