import { loadComponent } from '../../scripts/utils.js';
import { snakes } from '../../data/snakes.js';

export async function SnakeGrid() {
    const component = await loadComponent('src/components/database/SnakeGrid.html');
    const grid = component.querySelector('#snake-grid');
    const noResults = component.querySelector('#no-results');

    // Load SnakeCard template
    const cardTemplateResponse = await fetch('src/components/database/SnakeCard.html');
    const cardTemplateHtml = await cardTemplateResponse.text();
    const parser = new DOMParser();
    const cardDoc = parser.parseFromString(cardTemplateHtml, 'text/html');
    const cardTemplate = cardDoc.querySelector('.snake-card');

    // Inject card styles if not already present
    const cardStyles = cardDoc.querySelectorAll('style');
    cardStyles.forEach(style => document.head.appendChild(style));

    const renderSnakes = (filteredSnakes) => {
        grid.innerHTML = '';

        if (filteredSnakes.length === 0) {
            noResults.classList.remove('hidden');
            return;
        }

        noResults.classList.add('hidden');

        filteredSnakes.forEach(snake => {
            const card = cardTemplate.cloneNode(true);

            // Populate Data
            const img = card.querySelector('.snake-image');
            img.src = snake.image;
            img.alt = snake.commonName;

            const badge = card.querySelector('.venom-badge');
            badge.textContent = snake.venomous ? 'Venomous' : 'Non-venomous';
            badge.classList.add(snake.venomous ? 'badge-venomous' : 'badge-non-venomous');

            card.querySelector('.common-name').textContent = snake.commonName;
            card.querySelector('.scientific-name').textContent = snake.scientificName;
            card.querySelector('.region-text').textContent = snake.region;
            card.querySelector('.danger-text').textContent = `${snake.dangerLevel} Danger`;

            // Click Event
            card.addEventListener('click', () => {
                window.dispatchEvent(new CustomEvent('open-snake-modal', { detail: { snake } }));
            });

            grid.appendChild(card);
        });
    };

    // Initial Render
    renderSnakes(snakes);

    // Listen for Filters
    window.addEventListener('filter-change', (e) => {
        const { search, venom, danger } = e.detail;

        const filtered = snakes.filter(snake => {
            const matchesSearch = snake.commonName.toLowerCase().includes(search.toLowerCase()) ||
                snake.scientificName.toLowerCase().includes(search.toLowerCase()) ||
                snake.region.toLowerCase().includes(search.toLowerCase());

            const matchesVenom = venom === 'all' ||
                (venom === 'venomous' && snake.venomous) ||
                (venom === 'non-venomous' && !snake.venomous);

            const matchesDanger = danger === 'all' || snake.dangerLevel === danger;

            return matchesSearch && matchesVenom && matchesDanger;
        });

        renderSnakes(filtered);
    });

    // Listen for View Toggle
    window.addEventListener('view-change', (e) => {
        const { view } = e.detail;
        if (view === 'list') {
            grid.classList.remove('grid-view');
            grid.classList.add('list-view');
        } else {
            grid.classList.remove('list-view');
            grid.classList.add('grid-view');
        }
    });

    return component;
}
