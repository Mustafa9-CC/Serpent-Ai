import { loadComponent } from '../../scripts/utils.js';

export async function SnakeModal() {
    const component = await loadComponent('src/components/database/SnakeModal.html');

    const modal = component; // The root element is the modal div
    const closeBtn = component.querySelector('.close-modal');

    const closeModal = () => {
        modal.classList.add('hidden');
    };

    closeBtn.addEventListener('click', closeModal);
    modal.addEventListener('click', (e) => {
        if (e.target === modal) closeModal();
    });

    // Listen for Open Event
    window.addEventListener('open-snake-modal', (e) => {
        const { snake } = e.detail;

        // Populate Data
        component.querySelector('#modal-image').src = snake.image;
        component.querySelector('#modal-common-name').textContent = snake.commonName;
        component.querySelector('#modal-scientific-name').textContent = snake.scientificName;
        component.querySelector('#modal-description').textContent = snake.description;
        component.querySelector('#modal-habitat').textContent = snake.habitat;
        component.querySelector('#modal-behavior').textContent = snake.behavior;
        component.querySelector('#modal-prevention').textContent = snake.prevention;

        const venomBadge = component.querySelector('#modal-venom-badge');
        venomBadge.textContent = snake.venomous ? 'Venomous' : 'Non-venomous';
        venomBadge.style.backgroundColor = snake.venomous ? 'var(--danger)' : 'var(--primary)';

        const dangerBadge = component.querySelector('#modal-danger-badge');
        dangerBadge.textContent = `${snake.dangerLevel} Danger`;

        modal.classList.remove('hidden');
    });

    return component;
}
