import { loadComponent } from '../../scripts/utils.js';

export async function DatabaseHeader() {
    const component = await loadComponent('src/components/database/DatabaseHeader.html');

    const searchInput = component.querySelector('#snake-search');
    const venomFilter = component.querySelector('#filter-venom');
    const dangerFilter = component.querySelector('#filter-danger');
    const toggleBtns = component.querySelectorAll('.toggle-btn');

    const emitFilterChange = () => {
        const event = new CustomEvent('filter-change', {
            detail: {
                search: searchInput.value,
                venom: venomFilter.value,
                danger: dangerFilter.value
            }
        });
        window.dispatchEvent(event);
    };

    // Event Listeners
    searchInput.addEventListener('input', emitFilterChange);
    venomFilter.addEventListener('change', emitFilterChange);
    dangerFilter.addEventListener('change', emitFilterChange);

    // View Toggle
    toggleBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            toggleBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            const view = btn.getAttribute('data-view');
            window.dispatchEvent(new CustomEvent('view-change', { detail: { view } }));
        });
    });

    return component;
}
