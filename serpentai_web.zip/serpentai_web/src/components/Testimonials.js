export class Testimonials {
  constructor() {
    this.init();
  }

  async init() {
    const container = document.querySelector('#testimonials-container');
    if (!container) return;

    try {
      const response = await fetch('src/components/Testimonials.html');
      const html = await response.text();
      container.innerHTML = html;
    } catch (error) {
      console.error('Error loading testimonials:', error);
    }
  }
}
