export class AppPreview {
  constructor() {
    this.init();
  }

  async init() {
    const container = document.querySelector('#app-preview-container');
    if (!container) return;

    try {
      const response = await fetch('src/components/AppPreview.html');
      const html = await response.text();
      container.innerHTML = html;
    } catch (error) {
      console.error('Error loading app preview:', error);
    }
  }
}
