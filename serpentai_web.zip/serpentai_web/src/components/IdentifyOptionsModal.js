import { loadComponent } from '../scripts/utils.js';

export async function IdentifyOptionsModal() {
    const component = await loadComponent('src/components/IdentifyOptionsModal.html');
    const modal = component;
    const closeBtn = component.querySelector('.close-btn');
    const cameraBtn = component.querySelector('#option-camera');
    const uploadBtn = component.querySelector('#option-upload');

    // Open Modal Logic
    window.openIdentifyModal = () => {
        modal.classList.remove('hidden');
    };

    const closeModal = () => {
        modal.classList.add('hidden');
    };

    closeBtn.addEventListener('click', closeModal);

    // Close on outside click
    modal.addEventListener('click', (e) => {
        if (e.target === modal) closeModal();
    });

    // Option Handlers
    cameraBtn.addEventListener('click', () => {
        closeModal();
        localStorage.setItem('identify_action', 'camera');
        window.location.hash = '#identify';
    });

    uploadBtn.addEventListener('click', () => {
        closeModal();
        localStorage.setItem('identify_action', 'upload');
        window.location.hash = '#identify';
    });

    return component;
}
