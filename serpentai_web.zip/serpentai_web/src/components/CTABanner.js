export class CTABanner {
  constructor() {
    this.init();
  }

  async init() {
    const container = document.querySelector('#cta-container');
    if (!container) return;

    try {
      const response = await fetch('src/components/CTABanner.html');
      const html = await response.text();
      container.innerHTML = html;
    } catch (error) {
      console.error('Error loading CTA banner:', error);
    }
  }
}
