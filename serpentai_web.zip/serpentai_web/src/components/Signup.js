import { loadComponent } from '../scripts/utils.js';
import { auth } from '../scripts/auth.js';

export async function Signup() {
    const component = await loadComponent('src/components/Signup.html');
    const modal = component; // The component IS the modal div
    const form = component.querySelector('#signup-form');
    const closeBtn = component.querySelector('.close-btn');
    const errorDiv = component.querySelector('.form-error');
    const emailInput = component.querySelector('#signup-email');
    const passwordInput = component.querySelector('#signup-password');
    const confirmPasswordInput = component.querySelector('#signup-confirm-password');
    const submitBtn = component.querySelector('button[type="submit"]');
    const googleBtn = component.querySelector('#google-signup-btn');
    const switchToLoginBtn = component.querySelector('#switch-to-login');

    // Google Sign Up
    if (googleBtn) {
        googleBtn.addEventListener('click', async () => {
            // Loading state
            googleBtn.disabled = true;
            googleBtn.innerHTML = 'Signing in...';

            const { error } = await auth.signInWithGoogle();
            if (error) {
                errorDiv.textContent = error.message;
                errorDiv.classList.remove('hidden');
                googleBtn.disabled = false;
                googleBtn.innerHTML = '<svg width="18" height="18" viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg"><path d="M17.64 9.20455C17.64 8.56636 17.5827 7.95273 17.4764 7.36364H9V10.845H13.8436C13.635 11.97 13.0009 12.9232 12.0477 13.5614V15.8195H14.9564C16.6582 14.2527 17.64 11.9455 17.64 9.20455Z" fill="#4285F4"/><path d="M9 18C11.43 18 13.4673 17.1941 14.9564 15.8195L12.0477 13.5614C11.2418 14.1014 10.2109 14.4205 9 14.4205C6.65591 14.4205 4.67182 12.8373 3.96409 10.71H0.957275V13.0418C2.43818 15.9832 5.48182 18 9 18Z" fill="#34A853"/><path d="M3.96409 10.71C3.78409 10.17 3.68182 9.59318 3.68182 9C3.68182 8.40682 3.78409 7.83 3.96409 7.29V4.95818H0.957275C0.347727 6.17318 0 7.54773 0 9C0 10.4523 0.347727 11.8268 0.957275 13.0418L3.96409 10.71Z" fill="#FBBC05"/><path d="M9 3.57955C10.3214 3.57955 11.5077 4.03364 12.4405 4.92545L15.0218 2.34409C13.4632 0.891818 11.4259 0 9 0C5.48182 0 2.43818 2.01682 0.957275 4.95818L3.96409 7.29C4.67182 5.16273 6.65591 3.57955 9 3.57955Z" fill="#EA4335"/></svg> Sign up with Google';
            }
        });
    }

    // Open/Close Logic
    window.openSignupModal = () => {
        modal.classList.remove('hidden');
        emailInput.focus();
    };

    const closeModal = () => {
        modal.classList.add('hidden');
        form.reset();
        errorDiv.classList.add('hidden');
    };

    closeBtn.addEventListener('click', closeModal);

    // Close on outside click
    modal.addEventListener('click', (e) => {
        if (e.target === modal) closeModal();
    });

    // Switch to Login
    switchToLoginBtn.addEventListener('click', (e) => {
        e.preventDefault();
        closeModal();
        if (window.openLoginModal) {
            window.openLoginModal();
        } else {
            console.error('Login modal not available');
        }
    });

    // Form Submission
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = emailInput.value;
        const password = passwordInput.value;
        const confirmPassword = confirmPasswordInput.value;

        // Basic Validation
        if (password !== confirmPassword) {
            errorDiv.textContent = "Passwords do not match";
            errorDiv.classList.remove('hidden');
            return;
        }

        // Loading state
        submitBtn.disabled = true;
        submitBtn.textContent = 'Creating Account...';
        errorDiv.classList.add('hidden');

        const { data, error } = await auth.signUp(email, password);

        if (error) {
            errorDiv.textContent = error.message;
            errorDiv.classList.remove('hidden');
            submitBtn.disabled = false;
            submitBtn.textContent = 'Sign Up';
        } else {
            // Success
            console.log('Signed up:', data);
            // Check if email confirmation is required
            if (data?.user && !data.session) {
                errorDiv.textContent = "Please check your email to confirm your account.";
                errorDiv.classList.remove('hidden');
                errorDiv.style.color = 'var(--primary)'; // Hack to show success message in error div
                errorDiv.style.backgroundColor = 'rgba(0, 179, 126, 0.1)';
                submitBtn.textContent = 'Sign Up';
                // Don't close modal immediately so they can read the message
            } else {
                closeModal();
                submitBtn.disabled = false;
                submitBtn.textContent = 'Sign Up';
                // Header will update automatically via auth state listener
            }
        }
    });

    return component;
}
