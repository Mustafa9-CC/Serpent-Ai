export class Header {
  constructor() {
    this.init();
  }

  async init() {
    const headerContainer = document.querySelector('#header-container');
    if (!headerContainer) return;

    try {
      const response = await fetch('src/components/Header.html');
      const html = await response.text();
      headerContainer.innerHTML = html;

      this.setupThemeToggle();
      this.setupMobileMenu();
      this.setupScrollEffect();
      this.checkAuth();
    } catch (error) {
      console.error('Error loading header:', error);
    }
  }

  async checkAuth() {
    const { auth } = await import('../scripts/auth.js');

    // Initial check
    const user = await auth.getUser();
    this.updateAuthUI(user);

    // Subscribe to changes
    auth.onAuthStateChange((event, session) => {
      this.updateAuthUI(session?.user || null);
    });
  }

  async updateAuthUI(user) {
    const loginBtn = document.querySelector('#header-login-btn');
    const headerActions = document.querySelector('.header-actions');

    if (!loginBtn && !document.querySelector('#header-user-btn')) return;
    if (!headerActions) return;

    if (user) {
      // User is logged in
      const displayName = user.user_metadata?.full_name || user.email?.split('@')[0] || 'User';
      const avatarUrl = user.user_metadata?.avatar_url;
      let avatarHtml = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>`;

      if (avatarUrl) {
        try {
          let finalAvatarUrl = avatarUrl;
          if (!avatarUrl.startsWith('http')) {
            const { storage } = await import('../scripts/storage.js');
            const signedUrl = await storage.getSignedUrl(avatarUrl);
            if (signedUrl) finalAvatarUrl = signedUrl;
          }

          if (finalAvatarUrl) {
            avatarHtml = `<img src="${finalAvatarUrl}" alt="Profile" style="width: 24px; height: 24px; border-radius: 50%; object-fit: cover; margin-left: 4px;">`;
          }
        } catch (e) {
          console.error('Error loading avatar:', e);
        }
      }

      // Create user button/menu (Desktop - With Avatar)
      const userBtn = document.createElement('a');
      userBtn.href = '#dashboard';
      userBtn.className = 'btn btn-primary';
      userBtn.id = 'header-user-btn';
      userBtn.style.display = 'flex';
      userBtn.style.alignItems = 'center';
      userBtn.style.gap = '8px';
      userBtn.innerHTML = `
        <span>${displayName}</span>
        ${avatarHtml}
      `;

      // Replace login button if it exists, or update existing user button
      const existingUserBtn = document.querySelector('#header-user-btn');
      const currentLoginBtn = document.querySelector('#header-login-btn');

      if (existingUserBtn) {
        existingUserBtn.replaceWith(userBtn);
      } else if (currentLoginBtn) {
        currentLoginBtn.replaceWith(userBtn);
      }

      // Update Mobile Button (No Avatar)
      const mobileLoginBtn = document.querySelector('#mobile-login-btn');
      const mobileUserBtn = document.querySelector('#mobile-user-btn');

      const newMobileBtn = document.createElement('a');
      newMobileBtn.href = '#dashboard';
      newMobileBtn.className = 'btn btn-primary mobile-auth-btn';
      newMobileBtn.id = 'mobile-user-btn';
      newMobileBtn.textContent = displayName;

      if (mobileUserBtn) {
        mobileUserBtn.replaceWith(newMobileBtn);
      } else if (mobileLoginBtn) {
        mobileLoginBtn.replaceWith(newMobileBtn);
      }

    } else {
      // User is logged out
      // If we have a user button, replace it back with login button
      const existingUserBtn = document.querySelector('#header-user-btn');
      if (existingUserBtn) {
        const newLoginBtn = document.createElement('a');
        newLoginBtn.href = '#login';
        newLoginBtn.id = 'header-login-btn';
        newLoginBtn.className = 'btn btn-primary';
        newLoginBtn.textContent = 'Login / Sign Up';
        existingUserBtn.replaceWith(newLoginBtn);
      }

      // Reset Mobile Button
      const mobileUserBtn = document.querySelector('#mobile-user-btn');
      if (mobileUserBtn) {
        const newMobileLoginBtn = document.createElement('a');
        newMobileLoginBtn.href = '#login';
        newMobileLoginBtn.id = 'mobile-login-btn';
        newMobileLoginBtn.className = 'btn btn-primary mobile-auth-btn';
        newMobileLoginBtn.textContent = 'Login / Sign Up';
        mobileUserBtn.replaceWith(newMobileLoginBtn);
      }
    }
  }

  setupThemeToggle() {
    const toggleBtn = document.getElementById('theme-toggle');
    if (!toggleBtn) return;

    // Check saved theme or system preference
    const savedTheme = localStorage.getItem('theme');
    const systemDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

    if (savedTheme === 'dark' || (!savedTheme && systemDark)) {
      document.documentElement.setAttribute('data-theme', 'dark');
    }

    toggleBtn.addEventListener('click', () => {
      const currentTheme = document.documentElement.getAttribute('data-theme');
      const newTheme = currentTheme === 'dark' ? 'light' : 'dark';

      document.documentElement.setAttribute('data-theme', newTheme);
      localStorage.setItem('theme', newTheme);
    });
  }

  setupMobileMenu() {
    const menuBtn = document.querySelector('.mobile-menu-btn');
    const mobileMenu = document.querySelector('.mobile-menu');
    const mobileLinks = document.querySelectorAll('.mobile-nav-link, #mobile-login-btn');

    if (menuBtn && mobileMenu) {
      menuBtn.addEventListener('click', () => {
        mobileMenu.classList.toggle('open');

        // Update icon (optional, can be enhanced later)
        const isOpen = mobileMenu.classList.contains('open');
        menuBtn.setAttribute('aria-expanded', isOpen);
      });

      // Close menu when a link is clicked
      mobileLinks.forEach(link => {
        link.addEventListener('click', () => {
          mobileMenu.classList.remove('open');
        });
      });

      // Close menu when clicking outside
      document.addEventListener('click', (e) => {
        if (!mobileMenu.contains(e.target) && !menuBtn.contains(e.target) && mobileMenu.classList.contains('open')) {
          mobileMenu.classList.remove('open');
        }
      });
    }
  }

  setupScrollEffect() {
    const header = document.querySelector('.header');
    window.addEventListener('scroll', () => {
      if (window.scrollY > 10) {
        header.style.boxShadow = 'var(--shadow-sm)';
      } else {
        header.style.boxShadow = 'none';
      }
    });
  }
}
