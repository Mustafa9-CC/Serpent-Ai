import { loadComponent } from '../../scripts/utils.js';
import { auth } from '../../scripts/auth.js';
import { EditProfileModal } from '../dashboard/EditProfileModal.js';
import { mockActivity } from '../../data/mockData.js';

export async function ProfileLogic() {
    const component = await loadComponent('src/components/profile/ProfileLayout.html');

    // --- User Data ---
    // --- User Data ---
    const user = await auth.getUser();
    const { storage } = await import('../../scripts/storage.js'); // Import storage early

    const updateAvatarDisplay = async (avatarUrlOrPath) => {
        const avatarEl = component.querySelector('.profile-avatar');
        if (!avatarUrlOrPath) {
            avatarEl.textContent = (user.user_metadata?.full_name || user.email).charAt(0).toUpperCase();
            return;
        }

        let src = avatarUrlOrPath;
        if (!src.startsWith('http')) {
            // It's a path, get signed URL
            src = await storage.getSignedUrl(avatarUrlOrPath);
        }

        if (src) {
            avatarEl.innerHTML = `<img src="${src}" alt="Avatar">`;
        }
    };

    if (user) {
        // Basic Info
        component.querySelector('.profile-name').textContent = user.user_metadata?.full_name || 'User';
        component.querySelector('.profile-email').textContent = user.email;

        // Initial Avatar Load
        await updateAvatarDisplay(user.user_metadata?.avatar_url);

        // Bio & Location
        if (user.user_metadata?.bio) {
            component.querySelector('.profile-bio').textContent = user.user_metadata.bio;
        }
        if (user.user_metadata?.location) {
            component.querySelector('#detail-location').textContent = user.user_metadata.location;
        }

        // --- Avatar Upload Logic ---
        const avatarBtn = component.querySelector('.btn-change-avatar');
        const avatarInput = component.querySelector('#avatar-upload');

        avatarBtn.addEventListener('click', () => {
            avatarInput.click();
        });

        avatarInput.addEventListener('change', async (e) => {
            const file = e.target.files[0];
            if (!file) return;

            // Show loading state (optional, maybe change button text or cursor)
            avatarBtn.textContent = '...';

            try {
                // 1. Upload File
                const uploadedFile = await storage.uploadFile(file);
                if (!uploadedFile) throw new Error('Upload failed');

                // 2. Update User Metadata
                const { error } = await auth.updateProfile({
                    avatar_url: uploadedFile.name // Store filename
                });

                if (error) throw error;

                // 3. Update UI
                await updateAvatarDisplay(uploadedFile.name);

                // Dispatch event to update other components (Sidebar, etc.)
                window.dispatchEvent(new CustomEvent('profile-updated'));

            } catch (err) {
                console.error('Avatar upload error:', err);
                alert('Failed to update profile picture.');
            } finally {
                avatarBtn.textContent = '📷';
            }
        });
    }

    // --- Stats & Recent Uploads (Real Data) ---
    // --- Stats & Recent Uploads (Real Data) ---
    const files = await storage.listFiles();

    // Update Upload Count
    const uploadCount = files.length;
    component.querySelector('#stat-uploads').textContent = uploadCount;

    // Update Recent Uploads
    const recentGrid = component.querySelector('#recent-uploads-grid');

    if (uploadCount > 0) {
        recentGrid.innerHTML = '';
        // Sort by date (newest first)
        files.sort((a, b) => {
            if (a.name < b.name) return 1;
            if (a.name > b.name) return -1;
            return 0;
        });

        // Fetch all signed URLs in parallel
        const imagePromises = files.map(async (file) => {
            const url = await storage.getSignedUrl(file.name);
            return { file, url };
        });

        const images = await Promise.all(imagePromises);

        // Render in order
        images.forEach(({ file, url }) => {
            if (url) {
                const thumb = document.createElement('div');
                thumb.className = 'upload-thumb';
                thumb.style.position = 'relative'; // Ensure relative positioning for absolute child
                thumb.innerHTML = `
                    <img src="${url}" alt="${file.name}" loading="lazy" style="width: 100%; height: 100%; object-fit: cover; cursor: zoom-in;">
                    <button class="btn-delete-thumb" title="Delete" style="position: absolute; top: 5px; right: 5px; background: rgba(0,0,0,0.5); color: white; border: none; border-radius: 50%; width: 24px; height: 24px; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 12px;">✕</button>
                `;

                // Delete Click Handler
                const deleteBtn = thumb.querySelector('.btn-delete-thumb');
                deleteBtn.addEventListener('click', async (e) => {
                    e.stopPropagation(); // Prevent lightbox
                    if (confirm(`Delete ${file.name}?`)) {
                        const success = await storage.deleteFile(file.name);
                        if (success) {
                            thumb.remove();
                            // Update count
                            const countEl = component.querySelector('#stat-uploads');
                            if (countEl) countEl.textContent = parseInt(countEl.textContent || '0') - 1;

                            // Dispatch event
                            window.dispatchEvent(new CustomEvent('profile-updated'));
                        } else {
                            alert('Failed to delete file.');
                        }
                    }
                });

                // Lightbox Click Handler
                thumb.addEventListener('click', () => {
                    const overlay = document.createElement('div');
                    overlay.className = 'lightbox-overlay';
                    overlay.innerHTML = `<img src="${url}" alt="${file.name}" class="lightbox-image">`;
                    document.body.appendChild(overlay);

                    // Trigger animation
                    requestAnimationFrame(() => {
                        overlay.classList.add('visible');
                    });

                    // Close on click
                    overlay.addEventListener('click', () => {
                        overlay.classList.remove('visible');
                        setTimeout(() => {
                            overlay.remove();
                        }, 300);
                    });
                });

                recentGrid.appendChild(thumb);
            }
        });
    } else {
        recentGrid.innerHTML = '<div class="empty-state">No uploads yet.</div>';
    }

    // --- Edit Profile ---
    const editBtn = component.querySelector('#btn-edit-profile');
    if (editBtn) {
        editBtn.addEventListener('click', async () => {
            const modal = await EditProfileModal();
            document.body.appendChild(modal);

            // Open the modal
            if (window.openEditProfileModal) {
                window.openEditProfileModal();
            }

            // Listen for updates to refresh this page
            const handleUpdate = async () => {
                // Re-fetch user and update UI
                const updatedUser = await auth.getUser();
                if (updatedUser) {
                    component.querySelector('.profile-name').textContent = updatedUser.user_metadata?.full_name || 'User';
                    if (updatedUser.user_metadata?.bio) component.querySelector('.profile-bio').textContent = updatedUser.user_metadata.bio;
                    if (updatedUser.user_metadata?.location) component.querySelector('#detail-location').textContent = updatedUser.user_metadata.location;
                }
            };
            window.addEventListener('profile-updated', handleUpdate, { once: true });
        });
    }

    return component;
}
