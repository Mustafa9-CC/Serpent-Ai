export class HowItWorks {
  constructor() {
    this.init();
  }

  async init() {
    const container = document.querySelector('#how-it-works-container');
    if (!container) return;

    try {
      const response = await fetch('src/components/HowItWorks.html');
      const html = await response.text();
      container.innerHTML = html;
    } catch (error) {
      console.error('Error loading how it works:', error);
    }
  }
}
