export class Footer {
    constructor() {
        this.init();
    }

    async init() {
        const container = document.querySelector('#footer-container');
        if (!container) return;

        try {
            const response = await fetch('src/components/Footer.html');
            const html = await response.text();
            container.innerHTML = html;
        } catch (error) {
            console.error('Error loading footer:', error);
        }
    }
}
