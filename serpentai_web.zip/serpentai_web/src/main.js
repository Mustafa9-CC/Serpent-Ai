import { Header } from './components/Header.js';
import { Hero } from './components/Hero.js';
import { Features } from './components/Features.js';
import { HowItWorks } from './components/HowItWorks.js';
import { AppPreview } from './components/AppPreview.js';
import { Testimonials } from './components/Testimonials.js';
import { CTABanner } from './components/CTABanner.js';
import { Footer } from './components/Footer.js';

// Import Pages
import { Identify } from './pages/Identify.js';
import { Database } from './pages/Database.js';
import { Dashboard } from './pages/Dashboard.js';
import { Activity } from './pages/Activity.js';
import { Emergency } from './pages/Emergency.js';
import { Profile } from './pages/Profile.js';
import { Settings } from './pages/Settings.js';

// Import Modals
import { Login } from './components/Login.js';
import { Signup } from './components/Signup.js';
import { auth } from './scripts/auth.js';

const app = document.getElementById('app');

// Router Configuration
const routes = {
  '': renderLanding,
  '#home': renderLanding,
  '#identify': () => renderPage(Identify),
  '#database': () => renderPage(Database),
  '#dashboard': () => renderPage(Dashboard),
  '#activity': () => renderPage(Activity),
  '#emergency': () => renderPage(Emergency),
  '#profile': () => renderPage(Profile),
  '#settings': () => renderPage(Settings),
};

const protectedRoutes = [
  '#dashboard',
  '#activity',
  '#profile',
  '#settings'
];

async function renderLanding() {
  // Restore Landing Page HTML structure
  app.innerHTML = `
        <div id="header-container"></div>
        <main>
            <div id="hero-container"></div>
            <div id="features-container"></div>
            <div id="how-it-works-container"></div>
            <div id="app-preview-container"></div>
            <div id="testimonials-container"></div>
            <div id="cta-container"></div>
        </main>
        <div id="footer-container"></div>
        <div id="modals-container"></div>
    `;

  // Initialize Landing Page Components
  new Header();
  new Hero();
  new Features();
  new HowItWorks();
  new AppPreview();
  new Testimonials();
  new CTABanner();
  new Footer();

  // Initialize Modals
  try {
    const loginModal = await Login();
    const signupModal = await Signup();
    const modalsContainer = document.getElementById('modals-container');
    if (modalsContainer) {
      modalsContainer.appendChild(loginModal);
      modalsContainer.appendChild(signupModal);

      // Load Identify Options Modal
      const { IdentifyOptionsModal } = await import('./components/IdentifyOptionsModal.js');
      const identifyModal = await IdentifyOptionsModal();
      modalsContainer.appendChild(identifyModal);
    }
  } catch (error) {
    console.error('Error loading modals:', error);
  }

  // Handle smooth scrolling for landing page links
  setupSmoothScroll();
}

async function renderPage(pageFunc) {
  app.innerHTML = ''; // Clear current content
  try {
    const pageContent = await pageFunc();
    app.appendChild(pageContent);
  } catch (error) {
    console.error('Error rendering page:', error);
    app.innerHTML = '<div class="container"><p>Error loading page.</p></div>';
  }
}

function setupSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      const targetId = this.getAttribute('href');
      // Only smooth scroll if target exists on current page (Landing Page sections)
      const targetElement = document.querySelector(targetId);
      if (targetElement) {
        e.preventDefault();
        const headerOffset = 80;
        const elementPosition = targetElement.getBoundingClientRect().top;
        const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

        window.scrollTo({
          top: offsetPosition,
          behavior: "smooth"
        });
      }
    });
  });
}

async function router() {
  const hash = window.location.hash;

  // Handle Login/Signup Modals (overlay on current page if possible, or default to Landing)
  if (hash === '#login') {
    if (!document.getElementById('header-container') && !document.querySelector('.dashboard-layout')) {
      await renderLanding();
    }
    if (window.openLoginModal) window.openLoginModal();
    return;
  }
  if (hash === '#signup') {
    if (!document.getElementById('header-container') && !document.querySelector('.dashboard-layout')) {
      await renderLanding();
    }
    if (window.openSignupModal) window.openSignupModal();
    return;
  }

  // Handle Page Navigation
  const route = routes[hash];

  // Check Protected Routes
  if (protectedRoutes.includes(hash)) {
    const user = await auth.getUser();
    if (!user) {
      // If modals aren't loaded or header is empty, we need to render the landing page
      const header = document.getElementById('header-container');
      if (!window.openLoginModal || (header && header.children.length === 0)) {
        await renderLanding();
      }

      // Clear hash to prevent infinite loop or confusion, effectively redirecting to landing
      window.history.replaceState(null, '', 'index.html#');

      if (window.openLoginModal) {
        window.openLoginModal("Please login to access this page.");
      }
      return;
    }
  }

  if (route) {
    await route();
  } else {
    // Default to Landing if route not found (or handle 404)
    await renderLanding();
  }
}

// Initialize Router
window.addEventListener('hashchange', router);
window.addEventListener('load', router);
