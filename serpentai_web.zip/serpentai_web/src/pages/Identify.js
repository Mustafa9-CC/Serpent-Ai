import { Sidebar } from '../components/dashboard/Sidebar.js';
import { DashboardHeader } from '../components/dashboard/DashboardHeader.js';
import { IdentifyUpload } from '../components/identify/IdentifyUpload.js';
import { IdentifyHistory } from '../components/identify/IdentifyHistory.js';

export async function Identify() {
    const container = document.createElement('div');
    container.className = 'dashboard-layout';

    // Sidebar
    const sidebar = await Sidebar('identify');

    // Main Content Area
    const mainContent = document.createElement('main');
    mainContent.className = 'dashboard-main';

    // Header
    const header = await DashboardHeader();
    header.querySelector('h1').textContent = 'Identify Snake';

    // Scrollable Content
    const contentScrollable = document.createElement('div');
    contentScrollable.className = 'dashboard-content';

    // Identify Page Layout
    const layout = document.createElement('div');
    layout.className = 'identify-layout';

    // Left Column: Upload & Results
    const mainColumn = document.createElement('div');
    mainColumn.className = 'identify-main-col';

    const uploadSection = await IdentifyUpload();
    mainColumn.appendChild(uploadSection);

    // Right Column: History (Desktop) or Below (Mobile)
    const sideColumn = document.createElement('div');
    sideColumn.className = 'identify-side-col';

    const historySection = await IdentifyHistory();
    sideColumn.appendChild(historySection);

    layout.appendChild(mainColumn);
    layout.appendChild(sideColumn);

    contentScrollable.appendChild(layout);
    mainContent.appendChild(header);
    mainContent.appendChild(contentScrollable);

    container.appendChild(sidebar);
    container.appendChild(mainContent);

    return container;
}

// Inject Page Styles
const style = document.createElement('style');
style.textContent = `
    .identify-layout {
        display: grid;
        grid-template-columns: 1fr 350px;
        gap: 2rem;
        max-width: 1400px;
        margin: 0 auto;
    }

    .identify-main-col {
        display: flex;
        flex-direction: column;
        gap: 2rem;
    }

    .identify-side-col {
        display: flex;
        flex-direction: column;
        gap: 2rem;
    }

    @media (max-width: 1024px) {
        .identify-layout {
            grid-template-columns: 1fr;
        }
    }
`;
document.head.appendChild(style);
