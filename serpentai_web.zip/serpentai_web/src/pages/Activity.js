import { Sidebar } from '../components/dashboard/Sidebar.js';
import { DashboardHeader } from '../components/dashboard/DashboardHeader.js';
import { ActivityTimeline } from '../components/activity/ActivityTimeline.js';

export async function Activity() {
    const container = document.createElement('div');
    container.className = 'dashboard-layout';

    // Structure: Sidebar + Main Content
    const sidebar = await Sidebar('activity');
    const mainContent = document.createElement('main');
    mainContent.className = 'dashboard-main';

    const header = await DashboardHeader();
    mainContent.appendChild(header);

    const contentScrollable = document.createElement('div');
    contentScrollable.className = 'dashboard-content';

    // Activity Content
    const activityContent = await ActivityTimeline();
    contentScrollable.appendChild(activityContent);

    mainContent.appendChild(contentScrollable);
    container.appendChild(sidebar);
    container.appendChild(mainContent);

    return container;
}
