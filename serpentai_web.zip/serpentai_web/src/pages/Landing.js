import { Header } from '../components/Header.js';
import { Hero } from '../components/Hero.js';
import { Features } from '../components/Features.js';
import { HowItWorks } from '../components/HowItWorks.js';
import { Testimonials } from '../components/Testimonials.js';
import { CTABanner } from '../components/CTABanner.js';
import { Footer } from '../components/Footer.js';
import { Login } from '../components/Login.js';
import { Signup } from '../components/Signup.js';

export async function Landing() {
    const container = document.createElement('div');

    // Load all components in parallel
    const components = await Promise.all([
        Header(),
        Hero(),
        Features(),
        HowItWorks(),
        Testimonials(),
        CTABanner(),
        Footer(),
        Login(),
        Signup()
    ]);

    components.forEach(component => {
        if (component) {
            container.appendChild(component);
        }
    });

    return container;
}
