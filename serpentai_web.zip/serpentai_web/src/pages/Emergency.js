import { Sidebar } from '../components/dashboard/Sidebar.js';
import { DashboardHeader } from '../components/dashboard/DashboardHeader.js';
import { loadComponent } from '../scripts/utils.js';

export async function Emergency() {
    const container = document.createElement('div');
    container.className = 'dashboard-layout';

    // Structure: Sidebar + Main Content
    const sidebar = await Sidebar('emergency');
    const mainContent = document.createElement('main');
    mainContent.className = 'dashboard-main';

    const header = await DashboardHeader();
    mainContent.appendChild(header);

    const contentScrollable = document.createElement('div');
    contentScrollable.className = 'dashboard-content emergency-content';

    // 1. Hero Section
    const hero = await loadComponent('src/components/emergency/EmergencyHero.html');
    contentScrollable.appendChild(hero);

    // 2. Dynamic Content Container
    const dynamicContainer = document.createElement('div');
    dynamicContainer.id = 'emergency-dynamic-content';
    contentScrollable.appendChild(dynamicContainer);

    // 3. Hospital Locator (Always visible at bottom)
    const hospitalLocator = await loadComponent('src/components/emergency/HospitalLocator.html');
    contentScrollable.appendChild(hospitalLocator);

    // Logic to switch views
    const loadActions = async () => {
        dynamicContainer.innerHTML = '';
        const actions = await loadComponent('src/components/emergency/EmergencyActions.html');
        dynamicContainer.appendChild(actions);

        actions.querySelector('#btn-bite').addEventListener('click', loadBiteGuide);
        actions.querySelector('#btn-spotted').addEventListener('click', loadSpottingGuide);
    };

    const loadBiteGuide = async () => {
        dynamicContainer.innerHTML = '';
        const guide = await loadComponent('src/components/emergency/BiteGuide.html');
        dynamicContainer.appendChild(guide);

        // Scroll to top of guide
        dynamicContainer.scrollIntoView({ behavior: 'smooth' });

        guide.querySelector('#back-from-bite').addEventListener('click', loadActions);
    };

    const loadSpottingGuide = async () => {
        dynamicContainer.innerHTML = '';
        const guide = await loadComponent('src/components/emergency/SpottingGuide.html');
        dynamicContainer.appendChild(guide);

        // Scroll to top of guide
        dynamicContainer.scrollIntoView({ behavior: 'smooth' });

        guide.querySelector('#back-from-spotted').addEventListener('click', loadActions);
    };

    // Initial Load
    await loadActions();

    // Hospital Locator Logic
    const hospitalBtn = hospitalLocator.querySelector('#btn-find-hospital');
    hospitalBtn.addEventListener('click', () => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition((position) => {
                const { latitude, longitude } = position.coords;
                const url = `https://www.google.com/maps/search/hospitals+near+me/@${latitude},${longitude},14z`;
                window.open(url, '_blank');
            }, (error) => {
                alert('Unable to retrieve location. Opening generic search.');
                window.open('https://www.google.com/maps/search/hospitals+near+me', '_blank');
            });
        } else {
            alert('Geolocation is not supported by this browser.');
            window.open('https://www.google.com/maps/search/hospitals+near+me', '_blank');
        }
    });

    mainContent.appendChild(contentScrollable);
    container.appendChild(sidebar);
    container.appendChild(mainContent);

    return container;
}

// Inject Page Specific Styles
const style = document.createElement('style');
style.textContent = `
    .emergency-content {
        max-width: 800px;
        margin: 0 auto;
        width: 100%;
    }
`;
document.head.appendChild(style);
