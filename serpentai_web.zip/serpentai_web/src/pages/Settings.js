import { Sidebar } from '../components/dashboard/Sidebar.js';
import { DashboardHeader } from '../components/dashboard/DashboardHeader.js';
import { SettingsLogic } from '../components/settings/SettingsLogic.js';

export async function Settings() {
    const container = document.createElement('div');
    container.className = 'dashboard-layout';

    // Structure: Sidebar + Main Content
    const sidebar = await Sidebar('settings');
    const mainContent = document.createElement('main');
    mainContent.className = 'dashboard-main';

    const header = await DashboardHeader();
    mainContent.appendChild(header);

    const contentScrollable = document.createElement('div');
    contentScrollable.className = 'dashboard-content';

    // Settings Content
    const settingsContent = await SettingsLogic();
    contentScrollable.appendChild(settingsContent);

    mainContent.appendChild(contentScrollable);
    container.appendChild(sidebar);
    container.appendChild(mainContent);

    return container;
}
