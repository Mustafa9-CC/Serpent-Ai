import { Sidebar } from '../components/dashboard/Sidebar.js';
import { DashboardHeader } from '../components/dashboard/DashboardHeader.js';
import { SnakeQuestionnaire } from '../components/identify/SnakeQuestionnaire.js';

export async function IdentifyQuestionnaire() {
    const container = document.createElement('div');
    container.className = 'dashboard-layout';

    // Sidebar
    const sidebar = await Sidebar('identify-quiz'); // New active state

    // Main Content Area
    const mainContent = document.createElement('main');
    mainContent.className = 'dashboard-main';

    // Header
    const header = await DashboardHeader();
    header.querySelector('h1').textContent = 'Identify by Description';

    // Scrollable Content
    const contentScrollable = document.createElement('div');
    contentScrollable.className = 'dashboard-content';

    // Questionnaire Component
    const questionnaire = await SnakeQuestionnaire();
    contentScrollable.appendChild(questionnaire);

    mainContent.appendChild(header);
    mainContent.appendChild(contentScrollable);

    container.appendChild(sidebar);
    container.appendChild(mainContent);

    return container;
}
