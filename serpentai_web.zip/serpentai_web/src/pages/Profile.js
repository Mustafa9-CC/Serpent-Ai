import { Sidebar } from '../components/dashboard/Sidebar.js';
import { DashboardHeader } from '../components/dashboard/DashboardHeader.js';
import { ProfileLogic } from '../components/profile/ProfileLogic.js';

export async function Profile() {
    const container = document.createElement('div');
    container.className = 'dashboard-layout';

    // Structure: Sidebar + Main Content
    const sidebar = await Sidebar('profile');
    const mainContent = document.createElement('main');
    mainContent.className = 'dashboard-main';

    const header = await DashboardHeader();
    mainContent.appendChild(header);

    const contentScrollable = document.createElement('div');
    contentScrollable.className = 'dashboard-content';

    // Profile Content
    const profileContent = await ProfileLogic();
    contentScrollable.appendChild(profileContent);

    mainContent.appendChild(contentScrollable);
    container.appendChild(sidebar);
    container.appendChild(mainContent);

    return container;
}
