import { Sidebar } from '../components/dashboard/Sidebar.js';
import { DashboardHeader } from '../components/dashboard/DashboardHeader.js';
import { StatsCards } from '../components/dashboard/StatsCards.js';
import { ProfilePanel } from '../components/dashboard/ProfilePanel.js';
import { UploadManager } from '../components/dashboard/UploadManager.js';
import { ActivityFeed } from '../components/dashboard/ActivityFeed.js';

export async function Dashboard() {
  const container = document.createElement('div');
  container.className = 'dashboard-layout';

  // Structure: Sidebar + Main Content
  const sidebar = await Sidebar('dashboard');
  const mainContent = document.createElement('main');
  mainContent.className = 'dashboard-main';

  const header = await DashboardHeader();
  mainContent.appendChild(header);

  const contentScrollable = document.createElement('div');
  contentScrollable.className = 'dashboard-content';

  // Dashboard Widgets
  const stats = await StatsCards();
  const profile = await ProfilePanel();

  // Grid for Uploads and Activity
  const bottomGrid = document.createElement('div');
  bottomGrid.className = 'dashboard-bottom-grid';

  const uploads = await UploadManager();
  const activity = await ActivityFeed();

  bottomGrid.appendChild(uploads);
  bottomGrid.appendChild(activity);

  contentScrollable.appendChild(stats);
  contentScrollable.appendChild(profile);
  contentScrollable.appendChild(bottomGrid);

  mainContent.appendChild(contentScrollable);

  // Edit Profile Modal
  const { EditProfileModal } = await import('../components/dashboard/EditProfileModal.js');
  const editModal = await EditProfileModal();
  container.appendChild(editModal);

  container.appendChild(sidebar);
  container.appendChild(mainContent);

  return container;
}

// Inject Dashboard Styles
const style = document.createElement('style');
style.textContent = `
  .dashboard-layout {
    display: flex;
    height: 100vh;
    background-color: var(--bg-body);
    overflow: hidden;
  }

  .dashboard-main {
    flex: 1;
    margin-left: 0; /* Sidebar is now overlay/hidden */
    display: flex;
    flex-direction: column;
    height: 100vh;
    transition: margin-left 0.3s ease;
  }

  /* .dashboard-main.sidebar-collapsed { margin-left: 80px; } */

  .dashboard-content {
    flex: 1;
    padding: 2rem;
    overflow-y: auto;
  }

  .dashboard-bottom-grid {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 1.5rem;
    height: 500px; /* Fixed height for scrollable areas inside if needed, or min-height */
  }

  @media (max-width: 1024px) {
    .dashboard-main {
      margin-left: 0;
    }
    
    .dashboard-bottom-grid {
      grid-template-columns: 1fr;
      height: auto;
    }
  }
`;
document.head.appendChild(style);
