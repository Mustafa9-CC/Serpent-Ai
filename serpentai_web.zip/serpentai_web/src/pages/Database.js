import { Sidebar } from '../components/dashboard/Sidebar.js';
import { DashboardHeader } from '../components/dashboard/DashboardHeader.js';
import { DatabaseHeader } from '../components/database/DatabaseHeader.js';
import { SnakeGrid } from '../components/database/SnakeGrid.js';
import { SnakeModal } from '../components/database/SnakeModal.js';

export async function Database() {
    const container = document.createElement('div');
    container.className = 'dashboard-layout';

    // Structure: Sidebar + Main Content
    const sidebar = await Sidebar('database');
    const mainContent = document.createElement('main');
    mainContent.className = 'dashboard-main';

    const header = await DashboardHeader();
    mainContent.appendChild(header);

    const contentScrollable = document.createElement('div');
    contentScrollable.className = 'dashboard-content';

    // Database Components
    const dbHeader = await DatabaseHeader();
    const snakeGrid = await SnakeGrid();

    contentScrollable.appendChild(dbHeader);
    contentScrollable.appendChild(snakeGrid);

    mainContent.appendChild(contentScrollable);

    // Modal (appended to container to be above everything)
    const modal = await SnakeModal();
    container.appendChild(modal);

    container.appendChild(sidebar);
    container.appendChild(mainContent);

    return container;
}
